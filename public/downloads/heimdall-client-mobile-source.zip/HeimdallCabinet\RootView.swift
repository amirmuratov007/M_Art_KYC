import SwiftUI

struct RootView: View {
    @EnvironmentObject private var session: SessionStore

    var body: some View {
        switch session.state {
        case .signedOut:
            SignInView()
        case .loading:
            LoadingView()
        case let .signedIn(snapshot):
            CabinetTabView(snapshot: snapshot)
        case let .failed(message):
            SignInView(errorMessage: message)
        }
    }
}

private struct LoadingView: View {
    var body: some View {
        ZStack {
            HeimdallTheme.background.ignoresSafeArea()
            VStack(spacing: 18) {
                ProgressView()
                    .controlSize(.large)
                    .tint(HeimdallTheme.accent)
                Text("Подключаем личный кабинет")
                    .font(.headline)
                    .foregroundStyle(HeimdallTheme.ink)
            }
        }
    }
}
