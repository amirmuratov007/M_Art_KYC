import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { statusLabel } from "../data/i18n";
import type { CheckStatus } from "../data/mockData";
import { useLocalization } from "../data/LocalizationContext";

const statusColors: Record<CheckStatus, { bg: string; fg: string }> = {
  New: { bg: "rgba(148, 163, 184, 0.14)", fg: "#CBD5E1" },
  "In progress": { bg: "rgba(56, 189, 248, 0.14)", fg: "#7DD3FC" },
  "Analyst review": { bg: "rgba(214, 168, 79, 0.16)", fg: "#F6D88A" },
  Completed: { bg: "rgba(34, 197, 94, 0.14)", fg: "#86EFAC" }
};

type Props = {
  status: CheckStatus;
};

export default function StatusBadge({ status }: Props) {
  const { language } = useLocalization();
  const colors = statusColors[status];
  return (
    <View style={[styles.badge, { backgroundColor: colors.bg }]}>
      <Text style={[styles.text, { color: colors.fg }]}>{statusLabel(status, language)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: "flex-start",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6
  },
  text: {
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase"
  }
});
