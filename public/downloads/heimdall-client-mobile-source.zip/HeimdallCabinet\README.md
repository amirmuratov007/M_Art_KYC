# Heimdall Cabinet for iPhone

Нативный SwiftUI-код личного кабинета для `heimdall-group.ru`.

## Как запустить

1. Откройте Xcode.
2. Создайте новый проект: `iOS` -> `App`.
3. Назовите проект `HeimdallCabinet`.
4. Удалите созданные Xcode файлы `ContentView.swift` и `HeimdallCabinetApp.swift`.
5. Перетащите все `.swift` файлы из этой папки в проект.
6. Убедитесь, что target deployment стоит iOS 16 или выше.
7. Запустите на iPhone Simulator.

Демо-вход:

- E-mail: `client@company.ru`
- Пароль: `demo`

## Что уже есть

- Авторизация.
- Главный экран со сводкой.
- Заявки и создание новой заявки.
- Документы, включая статус подписи.
- Финансы и счета.
- Уведомления.
- Профиль клиента.
- `HeimdallAPI` протокол для подключения реального API.
- `MockHeimdallAPI` с демо-данными.
- `LiveHeimdallAPI` с готовыми `URLSession` запросами.

## Подключение реального сайта

Когда будет готов API, замените `MockHeimdallAPI` в `HeimdallCabinetApp.swift` на реализацию, которая ходит в backend:

```swift
@StateObject private var session = SessionStore(api: LiveHeimdallAPI(baseURL: URL(string: "https://heimdall-group.ru")!))
```

Рекомендуемые backend endpoints:

- `POST /api/mobile/auth/login`
- `GET /api/mobile/cabinet`
- `POST /api/mobile/requests`
- `POST /api/mobile/notifications/read`

Если на сайте нет мобильного API, не используйте парсинг HTML личного кабинета: лучше добавить отдельные JSON endpoints, чтобы App Store не отклонил приложение из-за нестабильной авторизации и небезопасной обработки данных.
