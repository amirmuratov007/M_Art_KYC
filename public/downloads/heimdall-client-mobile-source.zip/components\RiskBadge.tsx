import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { riskLabel } from "../data/i18n";
import { useLocalization } from "../data/LocalizationContext";
import type { RiskLevel } from "../data/mockData";

const riskColors: Record<RiskLevel, { bg: string; fg: string }> = {
  Low: { bg: "rgba(34, 197, 94, 0.14)", fg: "#86EFAC" },
  Medium: { bg: "rgba(214, 168, 79, 0.16)", fg: "#F6D88A" },
  High: { bg: "rgba(248, 113, 113, 0.16)", fg: "#FCA5A5" }
};

type Props = {
  risk: RiskLevel;
};

export default function RiskBadge({ risk }: Props) {
  const { language } = useLocalization();
  const colors = riskColors[risk];
  return (
    <View style={[styles.badge, { backgroundColor: colors.bg }]}>
      <Text style={[styles.text, { color: colors.fg }]}>{riskLabel(risk, language)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: "flex-start",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6
  },
  text: {
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase"
  }
});
