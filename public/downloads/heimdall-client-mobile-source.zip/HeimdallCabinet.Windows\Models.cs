using System;
using System.Collections.Generic;

namespace HeimdallCabinet.Windows;

public sealed record UserProfile(
    Guid Id,
    string FullName,
    string Company,
    string Role,
    string Email,
    string Phone,
    string ManagerName);

public sealed record DashboardSummary(
    int ActiveRequests,
    int DocumentsToSign,
    int UnpaidInvoices,
    int LoyaltyPoints);

public enum RequestStatus
{
    New,
    InProgress,
    Waiting,
    Done
}

public sealed record CabinetRequest(
    Guid Id,
    string Title,
    string Service,
    RequestStatus Status,
    DateTime UpdatedAt,
    string Comment);

public enum DocumentKind
{
    Contract,
    Act,
    Invoice,
    Report
}

public sealed record CabinetDocument(
    Guid Id,
    string Title,
    DocumentKind Kind,
    DateTime Date,
    bool RequiresSignature);

public enum InvoiceStatus
{
    Paid,
    Pending,
    Overdue
}

public sealed record Invoice(
    Guid Id,
    string Number,
    decimal Amount,
    DateTime DueDate,
    InvoiceStatus Status);

public sealed record CabinetNotification(
    Guid Id,
    string Title,
    string Message,
    DateTime Date,
    bool IsUnread);

public sealed class CabinetSnapshot
{
    public CabinetSnapshot(
        UserProfile profile,
        DashboardSummary summary,
        List<CabinetRequest> requests,
        List<CabinetDocument> documents,
        List<Invoice> invoices,
        List<CabinetNotification> notifications)
    {
        Profile = profile;
        Summary = summary;
        Requests = requests;
        Documents = documents;
        Invoices = invoices;
        Notifications = notifications;
    }

    public UserProfile Profile { get; set; }
    public DashboardSummary Summary { get; set; }
    public List<CabinetRequest> Requests { get; }
    public List<CabinetDocument> Documents { get; }
    public List<Invoice> Invoices { get; }
    public List<CabinetNotification> Notifications { get; set; }
}

public static class DisplayText
{
    public static string ToRu(this RequestStatus status) => status switch
    {
        RequestStatus.New => "Новая",
        RequestStatus.InProgress => "В работе",
        RequestStatus.Waiting => "Ожидает клиента",
        RequestStatus.Done => "Завершена",
        _ => status.ToString()
    };

    public static string ToRu(this DocumentKind kind) => kind switch
    {
        DocumentKind.Contract => "Договор",
        DocumentKind.Act => "Акт",
        DocumentKind.Invoice => "Счет",
        DocumentKind.Report => "Отчет",
        _ => kind.ToString()
    };

    public static string ToRu(this InvoiceStatus status) => status switch
    {
        InvoiceStatus.Paid => "Оплачен",
        InvoiceStatus.Pending => "Ожидает оплаты",
        InvoiceStatus.Overdue => "Просрочен",
        _ => status.ToString()
    };
}
