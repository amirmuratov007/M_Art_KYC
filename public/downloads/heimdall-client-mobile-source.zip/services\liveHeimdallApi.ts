import { env } from "../config/env";
import { getSession } from "./tokenStorage";
import type {
  ClientSession,
  DashboardPayload,
  HeimdallApi,
  LoginRequest,
  RequestCheckPayload,
  RequestCheckResponse
} from "../types/api";

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const session = await getSession();
  const response = await fetch(`${env.apiBaseUrl}${path}`, {
    ...init,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(session?.accessToken ? { Authorization: `Bearer ${session.accessToken}` } : {}),
      ...init.headers
    }
  });

  if (!response.ok) {
    throw new Error(`HEIMDALL API request failed: ${response.status}`);
  }

  return (await response.json()) as T;
}

export const liveHeimdallApi: HeimdallApi = {
  login(requestBody: LoginRequest): Promise<ClientSession> {
    return request<ClientSession>("/auth/login", {
      method: "POST",
      body: JSON.stringify(requestBody)
    });
  },

  getDashboard(): Promise<DashboardPayload> {
    return request<DashboardPayload>("/client/dashboard");
  },

  getChecks() {
    return request<DashboardPayload>("/client/dashboard").then((payload) => payload.checks);
  },

  getCheck(checkId: string) {
    return request<DashboardPayload>("/client/dashboard").then((payload) =>
      payload.checks.find((check) => check.id === checkId)
    );
  },

  getReports() {
    return request("/client/reports");
  },

  getSignals() {
    return request("/client/signals");
  },

  getSiteContent() {
    return request("/site/content");
  },

  submitCheckRequest(payload: RequestCheckPayload): Promise<RequestCheckResponse> {
    return request<RequestCheckResponse>("/client/check-requests", {
      method: "POST",
      body: JSON.stringify(payload)
    });
  },

  async getReportDownloadUrl(reportId: string): Promise<string> {
    const response = await request<{ url: string }>(`/client/reports/${reportId}/download-url`);
    return response.url;
  }
};
