# HEIMDALL Mobile Launch Checklist

## 1. Production Shell

- Expo config created in `app.json`.
- Bundle ID / package name: `ru.heimdallgroup.client`.
- App icons and splash assets added in `assets/`.
- Dark UI and bilingual EN/RU interface are in place.

## 2. Website/API Integration

- API contract is documented in `docs/api-contract.md`.
- Mobile service layer is in `services/`.
- Development builds use mock adapter.
- Production builds use live API adapter.

## 3. Secure Authentication

- `expo-secure-store` added.
- Sessions are persisted in secure device storage on iOS/Android.
- Web preview uses localStorage only for local demonstration.

## 4. Internal Builds

Run:

```bash
npx eas login
npx eas build:configure
npx eas build --profile preview --platform ios
npx eas build --profile preview --platform android
```

## 5. Production Builds

Run:

```bash
npx eas build --profile production --platform ios
npx eas build --profile production --platform android
```

## 6. App Store Connect

- Create app with bundle ID `ru.heimdallgroup.client`.
- Add screenshots.
- Add review account.
- Add privacy policy URL.
- Complete privacy nutrition labels.
- Submit TestFlight build first.

## 7. Google Play Console

- Create app with package `ru.heimdallgroup.client`.
- Upload `.aab` from EAS production build.
- Add screenshots.
- Complete Data Safety form.
- Start with Internal testing track.

## 8. Final Release Gate

- Test login, language switch, dashboard, checks, reports, signals, support, and request flow on physical iPhone and Android devices.
- Verify API tenant isolation.
- Verify PDF signed URLs expire.
- Verify no production secrets are bundled into the app.
- Verify store metadata matches the final backend behavior.

## 9. External Blockers

These cannot be completed inside the repository:

- Apple Developer account access.
- App Store Connect app ID.
- Google Play Console service account JSON.
- Real privacy policy URL.
- Production API credentials.
- Physical device testing by the HEIMDALL team.
