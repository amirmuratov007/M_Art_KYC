import React from "react";
import { ScrollView, Text } from "react-native";
import ReportCard from "../components/ReportCard";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { t } from "../data/i18n";
import { screenStyles } from "./screenStyles";

export default function ReportsScreen() {
  const { language } = useLocalization();
  const { reports } = useAppData();
  const copy = t[language];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.reportsEyebrow}</Text>
      <Text style={screenStyles.title}>{copy.reportsTitle}</Text>
      <Text style={[screenStyles.muted, { marginBottom: 18, marginTop: 8 }]}>
        {copy.reportsCopy}
      </Text>
      {reports.map((report) => (
        <ReportCard key={report.id} report={report} />
      ))}
    </ScrollView>
  );
}
