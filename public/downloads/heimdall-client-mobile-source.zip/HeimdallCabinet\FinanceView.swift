import SwiftUI

struct FinanceView: View {
    let invoices: [Invoice]

    private var pendingTotal: Decimal {
        invoices
            .filter { $0.status != .paid }
            .map(\.amount)
            .reduce(0, +)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Card {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("К оплате")
                                .font(.subheadline)
                                .foregroundStyle(HeimdallTheme.muted)
                            Text(pendingTotal.rubles)
                                .font(.largeTitle.weight(.bold))
                                .foregroundStyle(HeimdallTheme.ink)
                            Button {} label: {
                                Label("Оплатить", systemImage: "creditcard")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(HeimdallTheme.accent)
                            .padding(.top, 6)
                        }
                    }

                    SectionHeader(title: "Счета", action: nil)

                    ForEach(invoices) { invoice in
                        Card {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(invoice.number)
                                        .font(.headline)
                                        .foregroundStyle(HeimdallTheme.ink)
                                    Text("До \(invoice.dueDate.shortRu)")
                                        .font(.subheadline)
                                        .foregroundStyle(HeimdallTheme.muted)
                                    Text(invoice.amount.rubles)
                                        .font(.title3.weight(.bold))
                                        .foregroundStyle(HeimdallTheme.ink)
                                }
                                Spacer()
                                StatusPill(text: invoice.status.rawValue, color: invoice.status.color)
                            }
                        }
                    }
                }
                .padding(16)
            }
            .background(HeimdallTheme.background)
            .navigationTitle("Финансы")
        }
    }
}

private extension Invoice.Status {
    var color: Color {
        switch self {
        case .paid:
            return .green
        case .pending:
            return HeimdallTheme.gold
        case .overdue:
            return HeimdallTheme.danger
        }
    }
}
