using System.Threading.Tasks;

namespace HeimdallCabinet.Windows;

public interface IHeimdallApi
{
    Task<CabinetSnapshot> SignInAsync(string email, string password);
    Task<CabinetSnapshot> RefreshCabinetAsync();
    Task<CabinetRequest> CreateRequestAsync(string title, string service, string comment);
    Task MarkNotificationsReadAsync();
}

public sealed class HeimdallApiException : Exception
{
    public HeimdallApiException(string message) : base(message)
    {
    }
}
