import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { localize, t } from "../data/i18n";
import { useLocalization } from "../data/LocalizationContext";
import type { Check } from "../data/mockData";
import RiskBadge from "./RiskBadge";
import StatusBadge from "./StatusBadge";

type Props = {
  check: Check;
  onOpen: () => void;
};

export default function CheckCard({ check, onOpen }: Props) {
  const { language } = useLocalization();
  const copy = t[language];

  return (
    <View style={styles.card}>
      <View style={styles.topRow}>
        <View style={styles.titleWrap}>
          <Text style={styles.subject}>{localize(check.subject, language)}</Text>
          <Text style={styles.type}>{localize(check.type, language)}</Text>
        </View>
        <Text style={styles.score}>{check.score}</Text>
      </View>

      <View style={styles.badgeRow}>
        <StatusBadge status={check.status} />
        <RiskBadge risk={check.risk} />
      </View>

      <View style={styles.metaRow}>
        <Text style={styles.meta}>{copy.deadline}: {localize(check.deadline, language)}</Text>
        <Text style={styles.meta}>{copy.analyst}: {localize(check.analyst, language)}</Text>
      </View>

      <Pressable onPress={onOpen} style={({ pressed }) => [styles.openButton, pressed && styles.pressed]}>
        <Text style={styles.openText}>{copy.open}</Text>
        <Ionicons color="#050816" name="chevron-forward" size={16} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  badgeRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginTop: 16
  },
  card: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(56, 189, 248, 0.12)",
    borderRadius: 22,
    borderWidth: 1,
    marginBottom: 14,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { height: 16, width: 0 },
    shadowOpacity: 0.24,
    shadowRadius: 26
  },
  meta: {
    color: "#94A3B8",
    fontSize: 12,
    lineHeight: 18
  },
  metaRow: {
    gap: 4,
    marginTop: 15
  },
  openButton: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#38BDF8",
    borderRadius: 14,
    flexDirection: "row",
    gap: 4,
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 10
  },
  openText: {
    color: "#050816",
    fontSize: 13,
    fontWeight: "900"
  },
  pressed: {
    opacity: 0.82
  },
  score: {
    color: "#D6A84F",
    fontSize: 32,
    fontWeight: "900"
  },
  subject: {
    color: "#F8FAFC",
    fontSize: 18,
    fontWeight: "800",
    lineHeight: 24
  },
  titleWrap: {
    flex: 1,
    paddingRight: 10
  },
  topRow: {
    alignItems: "flex-start",
    flexDirection: "row"
  },
  type: {
    color: "#94A3B8",
    fontSize: 13,
    marginTop: 5
  }
});
