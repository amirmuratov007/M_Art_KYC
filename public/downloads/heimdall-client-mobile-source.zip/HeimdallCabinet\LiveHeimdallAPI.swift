import Foundation

final class LiveHeimdallAPI: HeimdallAPI {
    private let baseURL: URL
    private let session: URLSession
    private var accessToken: String?

    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()

    private let encoder: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }()

    init(baseURL: URL, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    func signIn(email: String, password: String) async throws -> CabinetSnapshot {
        let response: AuthResponse = try await post(
            path: "/api/mobile/auth/login",
            body: AuthRequest(email: email, password: password),
            requiresAuth: false
        )
        accessToken = response.accessToken
        return response.cabinet
    }

    func refreshCabinet() async throws -> CabinetSnapshot {
        try await get(path: "/api/mobile/cabinet")
    }

    func createRequest(title: String, service: String, comment: String) async throws -> CabinetRequest {
        try await post(
            path: "/api/mobile/requests",
            body: CreateRequestPayload(title: title, service: service, comment: comment),
            requiresAuth: true
        )
    }

    func markNotificationsRead() async throws {
        let _: EmptyResponse = try await post(
            path: "/api/mobile/notifications/read",
            body: EmptyRequest(),
            requiresAuth: true
        )
    }

    private func get<Response: Decodable>(path: String) async throws -> Response {
        var request = URLRequest(url: endpointURL(path))
        request.httpMethod = "GET"
        applyHeaders(to: &request, requiresAuth: true)
        return try await perform(request)
    }

    private func post<Body: Encodable, Response: Decodable>(
        path: String,
        body: Body,
        requiresAuth: Bool
    ) async throws -> Response {
        var request = URLRequest(url: endpointURL(path))
        request.httpMethod = "POST"
        request.httpBody = try encoder.encode(body)
        applyHeaders(to: &request, requiresAuth: requiresAuth)
        return try await perform(request)
    }

    private func applyHeaders(to request: inout URLRequest, requiresAuth: Bool) {
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if requiresAuth, let accessToken {
            request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        }
    }

    private func endpointURL(_ path: String) -> URL {
        baseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/")))
    }

    private func perform<Response: Decodable>(_ request: URLRequest) async throws -> Response {
        let (data, response) = try await session.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw HeimdallAPIError.unavailable
        }

        switch httpResponse.statusCode {
        case 200..<300:
            return try decoder.decode(Response.self, from: data)
        case 401:
            throw HeimdallAPIError.invalidCredentials
        default:
            throw HeimdallAPIError.unavailable
        }
    }
}

private struct AuthRequest: Encodable {
    let email: String
    let password: String
}

private struct AuthResponse: Decodable {
    let accessToken: String
    let cabinet: CabinetSnapshot
}

private struct CreateRequestPayload: Encodable {
    let title: String
    let service: String
    let comment: String
}

private struct EmptyRequest: Encodable {}
private struct EmptyResponse: Decodable {}
