using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeimdallCabinetClassic
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm(new MockHeimdallApi()));
        }
    }

    internal sealed class LoginForm : Form
    {
        private readonly MockHeimdallApi api;
        private readonly TextBox emailBox = new TextBox();
        private readonly TextBox passwordBox = new TextBox();
        private readonly Label errorLabel = new Label();
        private readonly Button loginButton;

        public LoginForm(MockHeimdallApi api)
        {
            this.api = api;
            loginButton = Ui.PrimaryButton("Войти");

            Text = "Heimdall - вход";
            MinimumSize = new Size(430, 560);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(8, 24, 26);

            var shell = new TableLayoutPanel();
            shell.Dock = DockStyle.Fill;
            shell.ColumnCount = 1;
            shell.RowCount = 2;
            shell.Padding = new Padding(28);
            shell.BackColor = BackColor;
            shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 150));
            shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var brand = new FlowLayoutPanel();
            brand.FlowDirection = FlowDirection.TopDown;
            brand.Dock = DockStyle.Fill;
            brand.BackColor = BackColor;
            brand.Controls.Add(Ui.Label("HEIMDALL", new Font("Segoe UI", 28, FontStyle.Bold), Color.White));
            brand.Controls.Add(Ui.Label("Личный кабинет клиента", new Font("Segoe UI", 12), Color.FromArgb(216, 230, 228)));

            var card = Ui.Card();
            card.Dock = DockStyle.Top;
            card.Height = 310;

            var form = new TableLayoutPanel();
            form.Dock = DockStyle.Fill;
            form.ColumnCount = 1;
            form.RowCount = 7;
            form.BackColor = Ui.Surface;

            emailBox.Text = "client@company.ru";
            emailBox.Font = Ui.BodyFont;
            emailBox.Height = 32;

            passwordBox.Text = "demo";
            passwordBox.Font = Ui.BodyFont;
            passwordBox.Height = 32;
            passwordBox.UseSystemPasswordChar = true;

            errorLabel.AutoSize = true;
            errorLabel.ForeColor = Ui.Danger;
            errorLabel.Font = Ui.SmallFont;

            loginButton.Dock = DockStyle.Top;
            loginButton.Click += async delegate { await SignInAsync(); };

            form.Controls.Add(Ui.Label("Вход в личный кабинет", Ui.HeadingFont, Ui.Ink), 0, 0);
            form.Controls.Add(Ui.Label("E-mail", Ui.SmallFont, Ui.Muted), 0, 1);
            form.Controls.Add(emailBox, 0, 2);
            form.Controls.Add(Ui.Label("Пароль", Ui.SmallFont, Ui.Muted), 0, 3);
            form.Controls.Add(passwordBox, 0, 4);
            form.Controls.Add(errorLabel, 0, 5);
            form.Controls.Add(loginButton, 0, 6);

            card.Controls.Add(form);
            shell.Controls.Add(brand, 0, 0);
            shell.Controls.Add(card, 0, 1);
            Controls.Add(shell);
        }

        private async Task SignInAsync()
        {
            errorLabel.Text = "";
            loginButton.Enabled = false;
            loginButton.Text = "Подключаем...";

            try
            {
                var snapshot = await api.SignInAsync(emailBox.Text.Trim(), passwordBox.Text);
                var cabinet = new MainForm(api, snapshot);
                cabinet.FormClosed += delegate { Close(); };
                Hide();
                cabinet.Show();
            }
            catch (Exception ex)
            {
                errorLabel.Text = ex.Message;
                loginButton.Enabled = true;
                loginButton.Text = "Войти";
            }
        }
    }

    internal sealed class MainForm : Form
    {
        private readonly MockHeimdallApi api;
        private CabinetSnapshot snapshot;
        private readonly Panel content = new Panel();

        public MainForm(MockHeimdallApi api, CabinetSnapshot snapshot)
        {
            this.api = api;
            this.snapshot = snapshot;

            Text = "Heimdall - личный кабинет";
            MinimumSize = new Size(1060, 720);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Ui.Background;

            var shell = new TableLayoutPanel();
            shell.Dock = DockStyle.Fill;
            shell.ColumnCount = 2;
            shell.BackColor = Ui.Background;
            shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230));
            shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            shell.Controls.Add(BuildSidebar(), 0, 0);
            content.Dock = DockStyle.Fill;
            content.AutoScroll = true;
            content.Padding = new Padding(24);
            content.BackColor = Ui.Background;
            shell.Controls.Add(content, 1, 0);
            Controls.Add(shell);

            ShowDashboard();
        }

        private Control BuildSidebar()
        {
            var sidebar = new FlowLayoutPanel();
            sidebar.Dock = DockStyle.Fill;
            sidebar.FlowDirection = FlowDirection.TopDown;
            sidebar.WrapContents = false;
            sidebar.Padding = new Padding(16);
            sidebar.BackColor = Color.FromArgb(13, 35, 37);

            sidebar.Controls.Add(Ui.Label("HEIMDALL", new Font("Segoe UI", 22, FontStyle.Bold), Color.White));
            sidebar.Controls.Add(Ui.Label("Личный кабинет", Ui.SmallFont, Color.FromArgb(195, 212, 210)));
            sidebar.Controls.Add(NavButton("Главная", ShowDashboard));
            sidebar.Controls.Add(NavButton("Заявки", ShowRequests));
            sidebar.Controls.Add(NavButton("Документы", ShowDocuments));
            sidebar.Controls.Add(NavButton("Финансы", ShowFinance));
            sidebar.Controls.Add(NavButton("Профиль", ShowProfile));

            var logout = NavButton("Выйти", Close);
            logout.BackColor = Color.FromArgb(95, 31, 31);
            sidebar.Controls.Add(logout);
            return sidebar;
        }

        private Button NavButton(string text, Action action)
        {
            var button = Ui.PrimaryButton(text);
            button.BackColor = Color.FromArgb(25, 74, 73);
            button.Width = 190;
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.Click += delegate { action(); };
            return button;
        }

        private void SetContent(string title)
        {
            content.Controls.Clear();
            content.Controls.Add(Ui.Label(title, Ui.TitleFont, Ui.Ink));
        }

        private void ShowDashboard()
        {
            SetContent("Кабинет");
            content.Controls.Add(Ui.Label("Здравствуйте, " + snapshot.Profile.FullName, Ui.HeadingFont, Ui.Ink));
            content.Controls.Add(Ui.Label(snapshot.Profile.Company, Ui.BodyFont, Ui.Muted));

            var grid = new TableLayoutPanel();
            grid.ColumnCount = 4;
            grid.RowCount = 1;
            grid.Width = 780;
            grid.Height = 120;
            grid.Margin = new Padding(0, 12, 0, 12);
            for (var i = 0; i < 4; i++)
            {
                grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            }

            grid.Controls.Add(SummaryCard("Заявки", snapshot.Summary.ActiveRequests.ToString()), 0, 0);
            grid.Controls.Add(SummaryCard("На подпись", snapshot.Summary.DocumentsToSign.ToString()), 1, 0);
            grid.Controls.Add(SummaryCard("К оплате", snapshot.Summary.UnpaidInvoices.ToString()), 2, 0);
            grid.Controls.Add(SummaryCard("Баллы", snapshot.Summary.LoyaltyPoints.ToString()), 3, 0);
            content.Controls.Add(grid);

            content.Controls.Add(ManagerCard());
            content.Controls.Add(Ui.Label("Последние заявки", Ui.HeadingFont, Ui.Ink));
            foreach (var request in snapshot.Requests.Take(3))
            {
                content.Controls.Add(RequestCard(request));
            }

            content.Controls.Add(Ui.Label("Уведомления", Ui.HeadingFont, Ui.Ink));
            foreach (var notification in snapshot.Notifications.Take(2))
            {
                content.Controls.Add(NotificationCard(notification));
            }
        }

        private Panel SummaryCard(string title, string value)
        {
            var card = Ui.Card();
            card.Width = 180;
            card.Height = 100;
            card.Controls.Add(Stack(
                Ui.Label(value, new Font("Segoe UI", 24, FontStyle.Bold), Ui.Ink),
                Ui.Label(title, Ui.SmallFont, Ui.Muted)));
            return card;
        }

        private Panel ManagerCard()
        {
            var card = Ui.Card();
            card.Width = 780;
            card.Height = 105;
            card.Controls.Add(Stack(
                Ui.Label("Ваш менеджер", Ui.SmallFont, Ui.Muted),
                Ui.Label(snapshot.Profile.ManagerName, Ui.HeadingFont, Ui.Ink),
                Ui.Label("Ответит по заявкам, документам и оплатам", Ui.BodyFont, Ui.Muted)));
            return card;
        }

        private void ShowRequests()
        {
            SetContent("Заявки");
            var create = Ui.PrimaryButton("Создать заявку");
            create.Width = 180;
            create.Click += async delegate { await CreateRequestAsync(); };
            content.Controls.Add(create);

            foreach (var request in snapshot.Requests)
            {
                content.Controls.Add(RequestCard(request));
            }
        }

        private async Task CreateRequestAsync()
        {
            using (var dialog = new NewRequestForm())
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                await api.CreateRequestAsync(dialog.RequestTitle, dialog.Service, dialog.Comment);
                snapshot = await api.RefreshCabinetAsync();
                ShowRequests();
            }
        }

        private Panel RequestCard(CabinetRequest request)
        {
            var card = Ui.Card();
            card.Width = 780;
            card.Height = 125;
            card.Controls.Add(Stack(
                Ui.Label(request.Title + "  ·  " + request.StatusText, Ui.HeadingFont, Ui.Ink),
                Ui.Label(request.Service, Ui.BodyFont, Ui.Muted),
                Ui.Label(request.Comment, Ui.BodyFont, Ui.Muted),
                Ui.Label("Обновлено " + request.UpdatedAt.ToString("dd.MM.yyyy"), Ui.SmallFont, Ui.Muted)));
            return card;
        }

        private void ShowDocuments()
        {
            SetContent("Документы");
            foreach (var document in snapshot.Documents)
            {
                var suffix = document.RequiresSignature ? " · Подписать" : "";
                var card = Ui.Card();
                card.Width = 780;
                card.Height = 92;
                card.Controls.Add(Stack(
                    Ui.Label(document.Title + suffix, Ui.HeadingFont, Ui.Ink),
                    Ui.Label(document.KindText + " · " + document.Date.ToString("dd.MM.yyyy"), Ui.BodyFont, Ui.Muted)));
                content.Controls.Add(card);
            }
        }

        private void ShowFinance()
        {
            SetContent("Финансы");
            var pendingTotal = snapshot.Invoices
                .Where(invoice => invoice.Status != InvoiceStatus.Paid)
                .Sum(invoice => invoice.Amount);

            var totalCard = Ui.Card();
            totalCard.Width = 780;
            totalCard.Height = 125;
            totalCard.Controls.Add(Stack(
                Ui.Label("К оплате", Ui.BodyFont, Ui.Muted),
                Ui.Label(pendingTotal.ToString("C0", CultureInfo.GetCultureInfo("ru-RU")), new Font("Segoe UI", 24, FontStyle.Bold), Ui.Ink),
                Ui.Label("Оплата подключается через платежный шлюз сайта", Ui.SmallFont, Ui.Muted)));
            content.Controls.Add(totalCard);

            foreach (var invoice in snapshot.Invoices)
            {
                var card = Ui.Card();
                card.Width = 780;
                card.Height = 105;
                card.Controls.Add(Stack(
                    Ui.Label(invoice.Number + " · " + invoice.StatusText, Ui.HeadingFont, Ui.Ink),
                    Ui.Label("До " + invoice.DueDate.ToString("dd.MM.yyyy"), Ui.BodyFont, Ui.Muted),
                    Ui.Label(invoice.Amount.ToString("C0", CultureInfo.GetCultureInfo("ru-RU")), Ui.HeadingFont, Ui.Ink)));
                content.Controls.Add(card);
            }
        }

        private void ShowProfile()
        {
            SetContent("Профиль");
            content.Controls.Add(Ui.Label(snapshot.Profile.FullName, Ui.HeadingFont, Ui.Ink));
            content.Controls.Add(Ui.Label(snapshot.Profile.Company, Ui.BodyFont, Ui.Muted));
            content.Controls.Add(Ui.Label("E-mail: " + snapshot.Profile.Email, Ui.BodyFont, Ui.Ink));
            content.Controls.Add(Ui.Label("Телефон: " + snapshot.Profile.Phone, Ui.BodyFont, Ui.Ink));
            content.Controls.Add(Ui.Label("Менеджер: " + snapshot.Profile.ManagerName, Ui.BodyFont, Ui.Ink));

            var markRead = Ui.PrimaryButton("Отметить уведомления прочитанными");
            markRead.Width = 310;
            markRead.Click += async delegate
            {
                await api.MarkNotificationsReadAsync();
                snapshot = await api.RefreshCabinetAsync();
                ShowProfile();
            };
            content.Controls.Add(markRead);

            content.Controls.Add(Ui.Label("Уведомления", Ui.HeadingFont, Ui.Ink));
            foreach (var notification in snapshot.Notifications)
            {
                content.Controls.Add(NotificationCard(notification));
            }
        }

        private Panel NotificationCard(CabinetNotification notification)
        {
            var card = Ui.Card();
            card.Width = 780;
            card.Height = 98;
            var marker = notification.IsUnread ? "* " : "";
            card.Controls.Add(Stack(
                Ui.Label(marker + notification.Title, Ui.HeadingFont, Ui.Ink),
                Ui.Label(notification.Message, Ui.BodyFont, Ui.Muted),
                Ui.Label(notification.Date.ToString("dd.MM.yyyy"), Ui.SmallFont, Ui.Muted)));
            return card;
        }

        private static FlowLayoutPanel Stack(params Control[] controls)
        {
            var stack = new FlowLayoutPanel();
            stack.Dock = DockStyle.Fill;
            stack.FlowDirection = FlowDirection.TopDown;
            stack.WrapContents = false;
            stack.AutoScroll = false;
            stack.BackColor = Ui.Surface;
            stack.Controls.AddRange(controls);
            return stack;
        }
    }

    internal sealed class NewRequestForm : Form
    {
        private readonly TextBox titleBox = new TextBox();
        private readonly ComboBox serviceBox = new ComboBox();
        private readonly TextBox commentBox = new TextBox();

        public NewRequestForm()
        {
            Text = "Новая заявка";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(460, 420);
            BackColor = Ui.Background;

            var form = new TableLayoutPanel();
            form.Dock = DockStyle.Fill;
            form.Padding = new Padding(18);
            form.RowCount = 8;
            form.ColumnCount = 1;
            form.BackColor = Ui.Background;

            titleBox.Font = Ui.BodyFont;
            titleBox.Height = 32;

            serviceBox.DropDownStyle = ComboBoxStyle.DropDownList;
            serviceBox.Font = Ui.BodyFont;
            serviceBox.Items.AddRange(new object[]
            {
                "Автоматизация продаж",
                "Внедрение и обновление 1С",
                "Финансовый учет",
                "Бухгалтерия и кадровый учет",
                "B2B-портал"
            });
            serviceBox.SelectedIndex = 0;

            commentBox.Font = Ui.BodyFont;
            commentBox.Multiline = true;
            commentBox.Height = 110;

            var actions = new FlowLayoutPanel();
            actions.FlowDirection = FlowDirection.RightToLeft;
            actions.Dock = DockStyle.Fill;
            actions.Height = 48;

            var create = Ui.PrimaryButton("Создать");
            create.Width = 120;
            create.Click += delegate
            {
                if (string.IsNullOrWhiteSpace(RequestTitle))
                {
                    MessageBox.Show(this, "Введите тему заявки.", "Heimdall", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DialogResult = DialogResult.OK;
                Close();
            };

            var cancel = Ui.PrimaryButton("Отмена");
            cancel.BackColor = Color.FromArgb(90, 100, 112);
            cancel.Width = 120;
            cancel.Click += delegate
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };

            actions.Controls.Add(create);
            actions.Controls.Add(cancel);

            form.Controls.Add(Ui.Label("Тема", Ui.SmallFont, Ui.Muted));
            form.Controls.Add(titleBox);
            form.Controls.Add(Ui.Label("Услуга", Ui.SmallFont, Ui.Muted));
            form.Controls.Add(serviceBox);
            form.Controls.Add(Ui.Label("Комментарий", Ui.SmallFont, Ui.Muted));
            form.Controls.Add(commentBox);
            form.Controls.Add(actions);

            Controls.Add(form);
        }

        public string RequestTitle { get { return titleBox.Text.Trim(); } }
        public string Service { get { return serviceBox.SelectedItem == null ? "Автоматизация продаж" : serviceBox.SelectedItem.ToString(); } }
        public string Comment { get { return commentBox.Text.Trim(); } }
    }

    internal sealed class MockHeimdallApi
    {
        private readonly CabinetSnapshot snapshot = DemoData.CreateSnapshot();

        public async Task<CabinetSnapshot> SignInAsync(string email, string password)
        {
            await Task.Delay(250);
            if (!email.Contains("@") || password.Length < 4)
            {
                throw new InvalidOperationException("Проверьте e-mail и пароль.");
            }

            return snapshot;
        }

        public async Task<CabinetSnapshot> RefreshCabinetAsync()
        {
            await Task.Delay(100);
            return snapshot;
        }

        public async Task<CabinetRequest> CreateRequestAsync(string title, string service, string comment)
        {
            await Task.Delay(100);
            var request = new CabinetRequest
            {
                Id = Guid.NewGuid(),
                Title = title,
                Service = service,
                Status = RequestStatus.New,
                UpdatedAt = DateTime.Now,
                Comment = string.IsNullOrWhiteSpace(comment) ? "Заявка зарегистрирована." : comment
            };

            snapshot.Requests.Insert(0, request);
            snapshot.Summary.ActiveRequests += 1;
            return request;
        }

        public async Task MarkNotificationsReadAsync()
        {
            await Task.Delay(100);
            foreach (var notification in snapshot.Notifications)
            {
                notification.IsUnread = false;
            }
        }
    }

    internal static class DemoData
    {
        public static CabinetSnapshot CreateSnapshot()
        {
            return new CabinetSnapshot
            {
                Profile = new UserProfile
                {
                    Id = Guid.NewGuid(),
                    FullName = "Александр Мурадов",
                    Company = "ООО «Северный Контур»",
                    Role = "Клиент",
                    Email = "client@company.ru",
                    Phone = "+7 999 000-45-12",
                    ManagerName = "Мария Волкова"
                },
                Summary = new DashboardSummary
                {
                    ActiveRequests = 4,
                    DocumentsToSign = 2,
                    UnpaidInvoices = 1,
                    LoyaltyPoints = 1280
                },
                Requests = new List<CabinetRequest>
                {
                    new CabinetRequest { Id = Guid.NewGuid(), Title = "Настройка интеграции с CRM", Service = "Автоматизация продаж", Status = RequestStatus.InProgress, UpdatedAt = DateTime.Now.AddDays(-1), Comment = "Специалист проверяет обмен заказами и остатками." },
                    new CabinetRequest { Id = Guid.NewGuid(), Title = "Обновление 1С ERP", Service = "Внедрение и обновление 1С", Status = RequestStatus.Waiting, UpdatedAt = DateTime.Now.AddDays(-2), Comment = "Нужно согласовать окно работ." },
                    new CabinetRequest { Id = Guid.NewGuid(), Title = "Отчет по складу", Service = "Финансовый учет", Status = RequestStatus.Done, UpdatedAt = DateTime.Now.AddDays(-5), Comment = "Отчет передан ответственному менеджеру." },
                    new CabinetRequest { Id = Guid.NewGuid(), Title = "Проверка ЭДО", Service = "Бухгалтерия и кадровый учет", Status = RequestStatus.New, UpdatedAt = DateTime.Now, Comment = "Заявка зарегистрирована." }
                },
                Documents = new List<CabinetDocument>
                {
                    new CabinetDocument { Id = Guid.NewGuid(), Title = "Дополнительное соглашение №4", Kind = DocumentKind.Contract, Date = DateTime.Now.AddDays(-1), RequiresSignature = true },
                    new CabinetDocument { Id = Guid.NewGuid(), Title = "Акт выполненных работ за май", Kind = DocumentKind.Act, Date = DateTime.Now.AddDays(-3), RequiresSignature = true },
                    new CabinetDocument { Id = Guid.NewGuid(), Title = "Счет на сопровождение", Kind = DocumentKind.Invoice, Date = DateTime.Now.AddDays(-7), RequiresSignature = false },
                    new CabinetDocument { Id = Guid.NewGuid(), Title = "Отчет по SLA", Kind = DocumentKind.Report, Date = DateTime.Now.AddDays(-12), RequiresSignature = false }
                },
                Invoices = new List<Invoice>
                {
                    new Invoice { Id = Guid.NewGuid(), Number = "HG-2026-0521", Amount = 148000m, DueDate = DateTime.Now.AddDays(4), Status = InvoiceStatus.Pending },
                    new Invoice { Id = Guid.NewGuid(), Number = "HG-2026-0418", Amount = 96500m, DueDate = DateTime.Now.AddDays(-18), Status = InvoiceStatus.Paid },
                    new Invoice { Id = Guid.NewGuid(), Number = "HG-2026-0310", Amount = 112000m, DueDate = DateTime.Now.AddDays(-48), Status = InvoiceStatus.Paid }
                },
                Notifications = new List<CabinetNotification>
                {
                    new CabinetNotification { Id = Guid.NewGuid(), Title = "Документ ожидает подписи", Message = "Дополнительное соглашение №4 доступно в разделе документов.", Date = DateTime.Now, IsUnread = true },
                    new CabinetNotification { Id = Guid.NewGuid(), Title = "Обновлен статус заявки", Message = "Заявка по обновлению 1С переведена в статус ожидания клиента.", Date = DateTime.Now.AddDays(-1), IsUnread = true },
                    new CabinetNotification { Id = Guid.NewGuid(), Title = "Назначен менеджер", Message = "Ваш персональный менеджер: Мария Волкова.", Date = DateTime.Now.AddDays(-6), IsUnread = false }
                }
            };
        }
    }

    internal sealed class CabinetSnapshot
    {
        public UserProfile Profile;
        public DashboardSummary Summary;
        public List<CabinetRequest> Requests = new List<CabinetRequest>();
        public List<CabinetDocument> Documents = new List<CabinetDocument>();
        public List<Invoice> Invoices = new List<Invoice>();
        public List<CabinetNotification> Notifications = new List<CabinetNotification>();
    }

    internal sealed class UserProfile
    {
        public Guid Id;
        public string FullName;
        public string Company;
        public string Role;
        public string Email;
        public string Phone;
        public string ManagerName;
    }

    internal sealed class DashboardSummary
    {
        public int ActiveRequests;
        public int DocumentsToSign;
        public int UnpaidInvoices;
        public int LoyaltyPoints;
    }

    internal enum RequestStatus
    {
        New,
        InProgress,
        Waiting,
        Done
    }

    internal sealed class CabinetRequest
    {
        public Guid Id;
        public string Title;
        public string Service;
        public RequestStatus Status;
        public DateTime UpdatedAt;
        public string Comment;

        public string StatusText
        {
            get
            {
                switch (Status)
                {
                    case RequestStatus.New: return "Новая";
                    case RequestStatus.InProgress: return "В работе";
                    case RequestStatus.Waiting: return "Ожидает клиента";
                    case RequestStatus.Done: return "Завершена";
                    default: return Status.ToString();
                }
            }
        }
    }

    internal enum DocumentKind
    {
        Contract,
        Act,
        Invoice,
        Report
    }

    internal sealed class CabinetDocument
    {
        public Guid Id;
        public string Title;
        public DocumentKind Kind;
        public DateTime Date;
        public bool RequiresSignature;

        public string KindText
        {
            get
            {
                switch (Kind)
                {
                    case DocumentKind.Contract: return "Договор";
                    case DocumentKind.Act: return "Акт";
                    case DocumentKind.Invoice: return "Счет";
                    case DocumentKind.Report: return "Отчет";
                    default: return Kind.ToString();
                }
            }
        }
    }

    internal enum InvoiceStatus
    {
        Paid,
        Pending,
        Overdue
    }

    internal sealed class Invoice
    {
        public Guid Id;
        public string Number;
        public decimal Amount;
        public DateTime DueDate;
        public InvoiceStatus Status;

        public string StatusText
        {
            get
            {
                switch (Status)
                {
                    case InvoiceStatus.Paid: return "Оплачен";
                    case InvoiceStatus.Pending: return "Ожидает оплаты";
                    case InvoiceStatus.Overdue: return "Просрочен";
                    default: return Status.ToString();
                }
            }
        }
    }

    internal sealed class CabinetNotification
    {
        public Guid Id;
        public string Title;
        public string Message;
        public DateTime Date;
        public bool IsUnread;
    }

    internal static class Ui
    {
        public static readonly Color Background = Color.FromArgb(245, 247, 249);
        public static readonly Color Surface = Color.White;
        public static readonly Color Ink = Color.FromArgb(18, 24, 33);
        public static readonly Color Muted = Color.FromArgb(91, 101, 115);
        public static readonly Color Accent = Color.FromArgb(0, 102, 98);
        public static readonly Color Danger = Color.FromArgb(194, 46, 46);

        public static readonly Font TitleFont = new Font("Segoe UI", 20f, FontStyle.Bold);
        public static readonly Font HeadingFont = new Font("Segoe UI", 13f, FontStyle.Bold);
        public static readonly Font BodyFont = new Font("Segoe UI", 10f, FontStyle.Regular);
        public static readonly Font SmallFont = new Font("Segoe UI", 9f, FontStyle.Regular);

        public static Label Label(string text, Font font, Color color)
        {
            return new Label
            {
                AutoSize = true,
                Text = text,
                Font = font,
                ForeColor = color,
                Margin = new Padding(0, 0, 0, 6)
            };
        }

        public static Button PrimaryButton(string text)
        {
            var button = new Button();
            button.Text = text;
            button.AutoSize = false;
            button.Height = 40;
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = Accent;
            button.ForeColor = Color.White;
            button.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            button.Cursor = Cursors.Hand;
            button.Margin = new Padding(0, 6, 0, 6);
            return button;
        }

        public static Panel Card()
        {
            var panel = new Panel();
            panel.BackColor = Surface;
            panel.Padding = new Padding(16);
            panel.Margin = new Padding(0, 0, 0, 12);
            panel.BorderStyle = BorderStyle.FixedSingle;
            return panel;
        }
    }
}
