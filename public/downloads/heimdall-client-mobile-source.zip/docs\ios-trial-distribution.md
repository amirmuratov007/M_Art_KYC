# iOS Trial Distribution

HEIMDALL can be delivered to a test iPhone from the website after producing a signed IPA.

## Fast path

```bash
npm install
npx eas-cli login
npx eas-cli init
npm run build:ios:trial
```

When EAS asks for Apple credentials, use the Apple Developer account that owns the app identifier:

```text
ru.heimdallgroup.client
```

For a website download link, place the generated IPA and the static files from `site/ios-trial` at:

```text
https://heimdall-group.ru/mobile/ios/
```

The iPhone install URL is:

```text
https://heimdall-group.ru/mobile/ios/
```

Open it in Safari on the iPhone.

## What is already prepared

- EAS build profile: `ios-trial`
- Static install page: `site/ios-trial/index.html`
- OTA manifest template: `site/ios-trial/manifest.plist`
- Bundle identifier: `ru.heimdallgroup.client`
- Trial API environment: `https://staging-api.heimdall-group.ru/v1`

## What still requires external accounts

- Expo account login for EAS Build.
- Apple Developer Program membership.
- Registered device UDIDs for Ad Hoc/internal installation, unless using TestFlight.

Without Apple signing, iOS will reject the app even if the file is hosted on the site.
