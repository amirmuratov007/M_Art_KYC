import Foundation

struct UserProfile: Identifiable, Equatable, Codable {
    let id: UUID
    var fullName: String
    var company: String
    var role: String
    var email: String
    var phone: String
    var managerName: String
}

struct DashboardSummary: Equatable, Codable {
    var activeRequests: Int
    var documentsToSign: Int
    var unpaidInvoices: Int
    var loyaltyPoints: Int
}

struct CabinetRequest: Identifiable, Equatable, Codable {
    enum Status: String, CaseIterable, Codable {
        case new = "Новая"
        case inProgress = "В работе"
        case waiting = "Ожидает клиента"
        case done = "Завершена"
    }

    let id: UUID
    var title: String
    var service: String
    var status: Status
    var updatedAt: Date
    var comment: String
}

struct CabinetDocument: Identifiable, Equatable, Codable {
    enum Kind: String, Codable {
        case contract = "Договор"
        case act = "Акт"
        case invoice = "Счет"
        case report = "Отчет"
    }

    let id: UUID
    var title: String
    var kind: Kind
    var date: Date
    var requiresSignature: Bool
}

struct Invoice: Identifiable, Equatable, Codable {
    enum Status: String, Codable {
        case paid = "Оплачен"
        case pending = "Ожидает оплаты"
        case overdue = "Просрочен"
    }

    let id: UUID
    var number: String
    var amount: Decimal
    var dueDate: Date
    var status: Status
}

struct CabinetNotification: Identifiable, Equatable, Codable {
    let id: UUID
    var title: String
    var message: String
    var date: Date
    var isUnread: Bool
}

struct CabinetSnapshot: Equatable, Codable {
    var profile: UserProfile
    var summary: DashboardSummary
    var requests: [CabinetRequest]
    var documents: [CabinetDocument]
    var invoices: [Invoice]
    var notifications: [CabinetNotification]
}
