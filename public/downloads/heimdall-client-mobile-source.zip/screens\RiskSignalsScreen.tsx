import React from "react";
import { ScrollView, Text } from "react-native";
import SignalCard from "../components/SignalCard";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { t } from "../data/i18n";
import { screenStyles } from "./screenStyles";

export default function RiskSignalsScreen() {
  const { language } = useLocalization();
  const { signals } = useAppData();
  const copy = t[language];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.signalsEyebrow}</Text>
      <Text style={screenStyles.title}>{copy.signalsTitle}</Text>
      <Text style={[screenStyles.muted, { marginBottom: 18, marginTop: 8 }]}>
        {copy.signalsCopy}
      </Text>
      {signals.map((signal) => (
        <SignalCard key={signal.id} signal={signal} />
      ))}
    </ScrollView>
  );
}
