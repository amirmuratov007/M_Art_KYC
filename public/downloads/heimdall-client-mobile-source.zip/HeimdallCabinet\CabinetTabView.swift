import SwiftUI

struct CabinetTabView: View {
    let snapshot: CabinetSnapshot

    var body: some View {
        TabView {
            DashboardView(snapshot: snapshot)
                .tabItem { Label("Главная", systemImage: "house") }

            RequestsView(requests: snapshot.requests)
                .tabItem { Label("Заявки", systemImage: "list.bullet.rectangle") }

            DocumentsView(documents: snapshot.documents)
                .tabItem { Label("Документы", systemImage: "doc.text") }

            FinanceView(invoices: snapshot.invoices)
                .tabItem { Label("Финансы", systemImage: "creditcard") }

            ProfileView(profile: snapshot.profile, notifications: snapshot.notifications)
                .tabItem { Label("Профиль", systemImage: "person.crop.circle") }
        }
        .tint(HeimdallTheme.accent)
    }
}
