import { env } from "../config/env";
import { liveHeimdallApi } from "./liveHeimdallApi";
import { mockHeimdallApi } from "./mockHeimdallApi";

const useMockApi = env.appEnv !== "production";

export const heimdallApi = useMockApi ? mockHeimdallApi : liveHeimdallApi;
