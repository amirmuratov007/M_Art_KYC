import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { localize, severityLabel, t } from "../data/i18n";
import { useLocalization } from "../data/LocalizationContext";
import type { Signal, SignalSeverity } from "../data/mockData";

const severityColors: Record<SignalSeverity, { bg: string; fg: string }> = {
  Low: { bg: "rgba(34, 197, 94, 0.14)", fg: "#86EFAC" },
  Medium: { bg: "rgba(214, 168, 79, 0.16)", fg: "#F6D88A" },
  High: { bg: "rgba(248, 113, 113, 0.16)", fg: "#FCA5A5" },
  Critical: { bg: "rgba(239, 68, 68, 0.22)", fg: "#FECACA" }
};

type Props = {
  signal: Signal;
};

export default function SignalCard({ signal }: Props) {
  const { language } = useLocalization();
  const copy = t[language];
  const colors = severityColors[signal.severity];
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{localize(signal.title, language)}</Text>
        <View style={[styles.severity, { backgroundColor: colors.bg }]}>
          <Text style={[styles.severityText, { color: colors.fg }]}>{severityLabel(signal.severity, language)}</Text>
        </View>
      </View>
      <Text style={styles.affected}>{localize(signal.affected, language)}</Text>
      <Text style={styles.explanation}>{localize(signal.explanation, language)}</Text>
      <View style={styles.actionBox}>
        <Text style={styles.actionLabel}>{copy.recommendedAction}</Text>
        <Text style={styles.action}>{localize(signal.recommendedAction, language)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  action: {
    color: "#F8FAFC",
    fontSize: 13,
    lineHeight: 19,
    marginTop: 5
  },
  actionBox: {
    backgroundColor: "rgba(56, 189, 248, 0.08)",
    borderColor: "rgba(56, 189, 248, 0.16)",
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 14,
    padding: 12
  },
  actionLabel: {
    color: "#7DD3FC",
    fontSize: 11,
    fontWeight: "900",
    textTransform: "uppercase"
  },
  affected: {
    color: "#D6A84F",
    fontSize: 13,
    fontWeight: "800",
    marginTop: 6
  },
  card: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 14,
    padding: 16
  },
  explanation: {
    color: "#CBD5E1",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 10
  },
  header: {
    alignItems: "center",
    flexDirection: "row",
    gap: 10,
    justifyContent: "space-between"
  },
  severity: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6
  },
  severityText: {
    fontSize: 11,
    fontWeight: "900",
    textTransform: "uppercase"
  },
  title: {
    color: "#F8FAFC",
    flex: 1,
    fontSize: 17,
    fontWeight: "900",
    textTransform: "capitalize"
  }
});
