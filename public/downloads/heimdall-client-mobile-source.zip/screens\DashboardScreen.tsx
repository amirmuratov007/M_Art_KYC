import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import type { AppNavigation } from "../App";
import MetricCard from "../components/MetricCard";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { localize, riskLabel, statusLabel, t } from "../data/i18n";
import { colors, screenStyles } from "./screenStyles";

export default function DashboardScreen() {
  const navigation = useNavigation<AppNavigation>();
  const { language } = useLocalization();
  const { checks, client, notifications } = useAppData();
  const copy = t[language];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <View style={screenStyles.headerRow}>
        <View style={styles.headerCopy}>
          <Text style={screenStyles.eyebrow}>{copy.dashboardEyebrow}</Text>
          <Text style={screenStyles.title}>{client.company}</Text>
        </View>
        <Pressable onPress={() => navigation.navigate("Support")} style={styles.supportButton}>
          <Ionicons color={colors.gold} name="briefcase-outline" size={21} />
        </Pressable>
      </View>

      <View style={styles.contractPanel}>
        <View>
          <Text style={styles.contractLabel}>{copy.contractStatus}</Text>
          <Text style={styles.contractStatus}>{localize(client.contractStatus, language)}</Text>
        </View>
        <View style={styles.planPill}>
          <Text style={styles.planText}>{localize(client.plan, language)}</Text>
        </View>
      </View>

      <View style={styles.metricGrid}>
        <View style={styles.metricRow}>
          <MetricCard label={copy.monthlyChecks} value={client.monthlyChecksIncluded} helper={copy.monthlyChecksHelper} />
          <MetricCard label={copy.usedChecks} value={client.usedChecks} accent="gold" helper={copy.usedChecksHelper} />
        </View>
        <View style={styles.metricRow}>
          <MetricCard label={copy.riskIndex} value={`${client.riskIndex}/100`} accent="gold" helper={copy.riskIndexHelper} />
          <MetricCard label={copy.activeChecks} value={client.activeChecks} helper={`${client.completedReports} ${copy.completedReports}`} />
        </View>
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.priorityChecks}</Text>
      <View style={styles.compactList}>
        {checks.slice(0, 3).map((check) => (
          <Pressable
            key={check.id}
            onPress={() => navigation.navigate("CheckDetail", { checkId: check.id })}
            style={styles.compactItem}
          >
            <View style={styles.compactText}>
              <Text style={styles.compactTitle}>{localize(check.subject, language)}</Text>
              <Text style={styles.compactMeta}>{statusLabel(check.status, language)} · {riskLabel(check.risk, language)}</Text>
            </View>
            <Text style={styles.compactScore}>{check.score}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.latestNotifications}</Text>
      <View style={styles.notificationPanel}>
        {notifications.map((item) => (
          <View key={item.en} style={styles.notificationItem}>
            <View style={styles.notificationDot} />
            <Text style={styles.notificationText}>{localize(item, language)}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  compactItem: {
    alignItems: "center",
    borderBottomColor: "rgba(148, 163, 184, 0.11)",
    borderBottomWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 13
  },
  compactList: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 16
  },
  compactMeta: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4
  },
  compactScore: {
    color: colors.gold,
    fontSize: 22,
    fontWeight: "900"
  },
  compactText: {
    flex: 1,
    paddingRight: 10
  },
  compactTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "800"
  },
  contractLabel: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "800",
    textTransform: "uppercase"
  },
  contractPanel: {
    alignItems: "center",
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(56, 189, 248, 0.16)",
    borderRadius: 24,
    borderWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 18,
    padding: 18
  },
  contractStatus: {
    color: colors.text,
    fontSize: 21,
    fontWeight: "900",
    marginTop: 5
  },
  headerCopy: {
    flex: 1,
    paddingRight: 14
  },
  metricGrid: {
    gap: 12
  },
  metricRow: {
    flexDirection: "row",
    gap: 12
  },
  notificationDot: {
    backgroundColor: colors.blue,
    borderRadius: 999,
    height: 7,
    marginTop: 6,
    width: 7
  },
  notificationItem: {
    flexDirection: "row",
    gap: 10,
    paddingVertical: 10
  },
  notificationPanel: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 6
  },
  notificationText: {
    color: "#CBD5E1",
    flex: 1,
    fontSize: 13,
    lineHeight: 19
  },
  planPill: {
    backgroundColor: "rgba(214, 168, 79, 0.14)",
    borderRadius: 999,
    flexShrink: 1,
    paddingHorizontal: 12,
    paddingVertical: 8
  },
  planText: {
    color: "#F6D88A",
    fontSize: 11,
    fontWeight: "900",
    textAlign: "center",
    textTransform: "uppercase"
  },
  supportButton: {
    alignItems: "center",
    backgroundColor: "rgba(214, 168, 79, 0.12)",
    borderColor: "rgba(214, 168, 79, 0.24)",
    borderRadius: 16,
    borderWidth: 1,
    height: 46,
    justifyContent: "center",
    width: 46
  }
});
