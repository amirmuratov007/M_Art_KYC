import SwiftUI

enum HeimdallTheme {
    static let background = Color(red: 0.96, green: 0.97, blue: 0.98)
    static let surface = Color.white
    static let ink = Color(red: 0.07, green: 0.09, blue: 0.13)
    static let muted = Color(red: 0.39, green: 0.43, blue: 0.50)
    static let accent = Color(red: 0.00, green: 0.40, blue: 0.38)
    static let gold = Color(red: 0.74, green: 0.56, blue: 0.24)
    static let danger = Color(red: 0.76, green: 0.18, blue: 0.18)
}

struct Card<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(16)
            .background(HeimdallTheme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            .shadow(color: .black.opacity(0.05), radius: 12, y: 4)
    }
}

struct StatusPill: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(.caption.weight(.semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(color.opacity(0.11))
            .clipShape(Capsule())
    }
}

extension Decimal {
    var rubles: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "RUB"
        formatter.currencySymbol = "₽"
        formatter.maximumFractionDigits = 0
        return formatter.string(from: self as NSDecimalNumber) ?? "\(self) ₽"
    }
}

extension Date {
    var shortRu: String {
        formatted(.dateTime.day().month(.abbreviated).year())
    }
}
