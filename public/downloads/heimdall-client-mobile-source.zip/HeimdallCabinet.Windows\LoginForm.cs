using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeimdallCabinet.Windows;

public sealed class LoginForm : Form
{
    private readonly IHeimdallApi _api;
    private readonly TextBox _emailBox = new();
    private readonly TextBox _passwordBox = new();
    private readonly Label _errorLabel = new();
    private readonly Button _loginButton;

    public LoginForm(IHeimdallApi api)
    {
        _api = api;
        _loginButton = Theme.Button("Войти");

        Text = "Heimdall - вход";
        MinimumSize = new Size(420, 560);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(8, 24, 26);

        var shell = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(28),
            BackColor = BackColor
        };
        shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 150));
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var brand = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.TopDown,
            Dock = DockStyle.Fill,
            BackColor = BackColor
        };
        brand.Controls.Add(Theme.Label("HEIMDALL", new Font("Segoe UI", 28, FontStyle.Bold), Color.White));
        brand.Controls.Add(Theme.Label("Личный кабинет клиента", new Font("Segoe UI", 12), Color.FromArgb(216, 230, 228)));

        var card = Theme.Card();
        card.Dock = DockStyle.Top;
        card.Height = 300;

        var form = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 7,
            BackColor = Theme.Surface
        };

        _emailBox.Text = "client@company.ru";
        _emailBox.Height = 32;
        _emailBox.Font = Theme.BodyFont;

        _passwordBox.Text = "demo";
        _passwordBox.Height = 32;
        _passwordBox.Font = Theme.BodyFont;
        _passwordBox.UseSystemPasswordChar = true;

        _errorLabel.AutoSize = true;
        _errorLabel.ForeColor = Theme.Danger;
        _errorLabel.Font = Theme.SmallFont;

        _loginButton.Dock = DockStyle.Top;
        _loginButton.Click += async (_, _) => await SignInAsync();

        form.Controls.Add(Theme.Label("Вход в личный кабинет", Theme.HeadingFont), 0, 0);
        form.Controls.Add(Theme.Label("E-mail", Theme.SmallFont, Theme.Muted), 0, 1);
        form.Controls.Add(_emailBox, 0, 2);
        form.Controls.Add(Theme.Label("Пароль", Theme.SmallFont, Theme.Muted), 0, 3);
        form.Controls.Add(_passwordBox, 0, 4);
        form.Controls.Add(_errorLabel, 0, 5);
        form.Controls.Add(_loginButton, 0, 6);

        card.Controls.Add(form);
        shell.Controls.Add(brand, 0, 0);
        shell.Controls.Add(card, 0, 1);
        Controls.Add(shell);
    }

    private async Task SignInAsync()
    {
        _errorLabel.Text = "";
        _loginButton.Enabled = false;
        _loginButton.Text = "Подключаем...";

        try
        {
            var snapshot = await _api.SignInAsync(_emailBox.Text.Trim(), _passwordBox.Text);
            var cabinet = new MainForm(_api, snapshot);
            cabinet.FormClosed += (_, _) => Close();
            Hide();
            cabinet.Show();
        }
        catch (Exception ex)
        {
            _errorLabel.Text = ex.Message;
            _loginButton.Enabled = true;
            _loginButton.Text = "Войти";
        }
    }
}
