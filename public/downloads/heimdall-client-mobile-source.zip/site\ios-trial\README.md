# HEIMDALL iPhone Trial Distribution

This folder is the static website package for private iPhone trial installation.

## Website path

Upload these files to:

```text
https://heimdall-group.ru/mobile/ios/
```

Required files:

```text
index.html
manifest.plist
HeimdallClient.ipa
icon-57.png
icon-512.png
```

The install button in `index.html` points to:

```text
itms-services://?action=download-manifest&url=https://heimdall-group.ru/mobile/ios/manifest.plist
```

## Build the iPhone trial app

```bash
npx eas-cli login
npx eas-cli init
npm run build:ios:trial
```

EAS must be authenticated and connected to an Apple Developer account. For iPhone installation outside the App Store, the IPA must be signed through an Apple-supported method:

- Ad Hoc or internal distribution for registered test devices.
- TestFlight for beta testers.
- Enterprise distribution only if the company has Apple Developer Enterprise Program access.

An unsigned IPA or simulator build will not install on a physical iPhone.

## After EAS finishes

1. Download the generated `.ipa`.
2. Rename it to `HeimdallClient.ipa`.
3. Upload it next to `manifest.plist`.
4. Upload app icons as `icon-57.png` and `icon-512.png`.
5. Open `https://heimdall-group.ru/mobile/ios/` in Safari on iPhone.

## Server requirements

- The website must be served over HTTPS.
- `manifest.plist` must be publicly reachable.
- `HeimdallClient.ipa` must be publicly reachable or reachable to the target iPhone.
- The MIME type for `.plist` should be `application/xml`.
