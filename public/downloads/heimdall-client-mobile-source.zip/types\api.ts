import type { Check, Report, Signal, SiteContentItem } from "../data/mockData";

export type ClientSession = {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  clientId: string;
};

export type LoginRequest = {
  email: string;
  password: string;
};

export type DashboardPayload = {
  client: typeof import("../data/mockData").client;
  notifications: typeof import("../data/mockData").notifications;
  checks: Check[];
};

export type RequestCheckPayload = {
  type: string;
  subject: string;
  jurisdiction: string;
  urgency: string;
  comment?: string;
};

export type RequestCheckResponse = {
  requestId: string;
  status: "accepted";
};

export type HeimdallApi = {
  login: (request: LoginRequest) => Promise<ClientSession>;
  getDashboard: () => Promise<DashboardPayload>;
  getChecks: () => Promise<Check[]>;
  getCheck: (checkId: string) => Promise<Check | undefined>;
  getReports: () => Promise<Report[]>;
  getSignals: () => Promise<Signal[]>;
  getSiteContent: () => Promise<SiteContentItem[]>;
  submitCheckRequest: (payload: RequestCheckPayload) => Promise<RequestCheckResponse>;
  getReportDownloadUrl: (reportId: string) => Promise<string>;
};
