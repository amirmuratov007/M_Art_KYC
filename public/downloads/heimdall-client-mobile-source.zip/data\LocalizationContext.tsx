import React, { createContext, useContext } from "react";
import type { Language } from "./mockData";

type LocalizationContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
};

export const LocalizationContext = createContext<LocalizationContextValue>({
  language: "en",
  setLanguage: () => undefined
});

export function useLocalization() {
  return useContext(LocalizationContext);
}
