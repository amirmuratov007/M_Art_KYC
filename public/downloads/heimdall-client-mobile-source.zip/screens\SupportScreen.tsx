import React from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useLocalization } from "../data/LocalizationContext";
import { localize, t } from "../data/i18n";
import { client } from "../data/mockData";
import { colors, screenStyles } from "./screenStyles";

export default function SupportScreen() {
  const { language } = useLocalization();
  const copy = t[language];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.supportEyebrow}</Text>
      <Text style={screenStyles.title}>{localize(client.plan, language)}</Text>

      <View style={styles.pricePanel}>
        <Text style={styles.priceLabel}>{copy.startingFrom}</Text>
        <Text style={styles.price}>200,000 ₽</Text>
        <Text style={styles.priceMeta}>{copy.perMonth}</Text>
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.included}</Text>
      <View style={styles.panel}>
        {copy.includedItems.map((item) => (
          <View key={item} style={styles.includedRow}>
            <Ionicons color={colors.blue} name="checkmark-circle-outline" size={18} />
            <Text style={styles.includedText}>{item}</Text>
          </View>
        ))}
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.analystContact}</Text>
      <View style={styles.contactPanel}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>EV</Text>
        </View>
        <View style={styles.contactCopy}>
          <Text style={styles.analyst}>{localize(client.analyst, language)}</Text>
          <Text style={styles.email}>{client.analystEmail}</Text>
        </View>
      </View>

      <Pressable
        onPress={() => Alert.alert(copy.contactAlertTitle, copy.contactAlertBody)}
        style={({ pressed }) => [styles.button, pressed && styles.pressed]}
      >
        <Text style={styles.buttonText}>{copy.contactHeimdall}</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  analyst: {
    color: colors.text,
    fontSize: 17,
    fontWeight: "900"
  },
  avatar: {
    alignItems: "center",
    backgroundColor: "rgba(214, 168, 79, 0.16)",
    borderColor: "rgba(214, 168, 79, 0.28)",
    borderRadius: 18,
    borderWidth: 1,
    height: 54,
    justifyContent: "center",
    width: 54
  },
  avatarText: {
    color: "#F6D88A",
    fontSize: 16,
    fontWeight: "900"
  },
  button: {
    alignItems: "center",
    backgroundColor: colors.blue,
    borderRadius: 16,
    marginTop: 20,
    paddingVertical: 16
  },
  buttonText: {
    color: colors.background,
    fontSize: 15,
    fontWeight: "900"
  },
  contactCopy: {
    flex: 1
  },
  contactPanel: {
    alignItems: "center",
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row",
    gap: 14,
    padding: 16
  },
  email: {
    color: colors.muted,
    fontSize: 13,
    marginTop: 5
  },
  includedRow: {
    flexDirection: "row",
    gap: 10,
    paddingVertical: 9
  },
  includedText: {
    color: "#CBD5E1",
    flex: 1,
    fontSize: 13,
    lineHeight: 20
  },
  panel: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    padding: 16
  },
  pressed: {
    opacity: 0.84
  },
  price: {
    color: colors.gold,
    fontSize: 42,
    fontWeight: "900",
    marginTop: 4
  },
  priceLabel: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "900",
    textTransform: "uppercase"
  },
  priceMeta: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "800",
    marginTop: 2
  },
  pricePanel: {
    backgroundColor: "rgba(214, 168, 79, 0.1)",
    borderColor: "rgba(214, 168, 79, 0.22)",
    borderRadius: 24,
    borderWidth: 1,
    marginTop: 18,
    padding: 20
  }
});
