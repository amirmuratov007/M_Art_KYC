import Constants from "expo-constants";

type AppEnv = "development" | "staging" | "production";

const extra = Constants.expoConfig?.extra ?? {};

export const env = {
  appEnv: (typeof extra.appEnv === "string" ? extra.appEnv : "development") as AppEnv,
  apiBaseUrl: typeof extra.apiBaseUrl === "string" ? extra.apiBaseUrl : "https://api.heimdall-group.ru/v1",
  siteBaseUrl: typeof extra.siteBaseUrl === "string" ? extra.siteBaseUrl : "https://heimdall-group.ru"
};
