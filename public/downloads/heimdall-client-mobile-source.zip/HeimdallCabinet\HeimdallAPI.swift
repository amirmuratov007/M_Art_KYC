import Foundation

protocol HeimdallAPI {
    func signIn(email: String, password: String) async throws -> CabinetSnapshot
    func refreshCabinet() async throws -> CabinetSnapshot
    func createRequest(title: String, service: String, comment: String) async throws -> CabinetRequest
    func markNotificationsRead() async throws
}

enum HeimdallAPIError: LocalizedError {
    case invalidCredentials
    case unavailable

    var errorDescription: String? {
        switch self {
        case .invalidCredentials:
            return "Проверьте e-mail и пароль."
        case .unavailable:
            return "Сервис временно недоступен."
        }
    }
}

final class MockHeimdallAPI: HeimdallAPI {
    private var snapshot = CabinetSnapshot.demo

    func signIn(email: String, password: String) async throws -> CabinetSnapshot {
        try await Task.sleep(nanoseconds: 450_000_000)
        guard email.contains("@"), password.count >= 4 else {
            throw HeimdallAPIError.invalidCredentials
        }
        return snapshot
    }

    func refreshCabinet() async throws -> CabinetSnapshot {
        try await Task.sleep(nanoseconds: 250_000_000)
        return snapshot
    }

    func createRequest(title: String, service: String, comment: String) async throws -> CabinetRequest {
        try await Task.sleep(nanoseconds: 300_000_000)
        let request = CabinetRequest(
            id: UUID(),
            title: title,
            service: service,
            status: .new,
            updatedAt: Date(),
            comment: comment
        )
        snapshot.requests.insert(request, at: 0)
        snapshot.summary.activeRequests += 1
        return request
    }

    func markNotificationsRead() async throws {
        snapshot.notifications = snapshot.notifications.map {
            var item = $0
            item.isUnread = false
            return item
        }
    }
}

extension CabinetSnapshot {
    static let demo = CabinetSnapshot(
        profile: UserProfile(
            id: UUID(),
            fullName: "Александр Мурадов",
            company: "ООО «Северный Контур»",
            role: "Клиент",
            email: "client@company.ru",
            phone: "+7 999 000-45-12",
            managerName: "Мария Волкова"
        ),
        summary: DashboardSummary(
            activeRequests: 4,
            documentsToSign: 2,
            unpaidInvoices: 1,
            loyaltyPoints: 1280
        ),
        requests: [
            CabinetRequest(id: UUID(), title: "Настройка интеграции с CRM", service: "Автоматизация продаж", status: .inProgress, updatedAt: .daysAgo(1), comment: "Специалист проверяет обмен заказами и остатками."),
            CabinetRequest(id: UUID(), title: "Обновление 1С ERP", service: "Внедрение и обновление 1С", status: .waiting, updatedAt: .daysAgo(2), comment: "Нужно согласовать окно работ."),
            CabinetRequest(id: UUID(), title: "Отчет по складу", service: "Финансовый учет", status: .done, updatedAt: .daysAgo(5), comment: "Отчет передан ответственному менеджеру."),
            CabinetRequest(id: UUID(), title: "Проверка ЭДО", service: "Бухгалтерия и кадровый учет", status: .new, updatedAt: .daysAgo(0), comment: "Заявка зарегистрирована.")
        ],
        documents: [
            CabinetDocument(id: UUID(), title: "Дополнительное соглашение №4", kind: .contract, date: .daysAgo(1), requiresSignature: true),
            CabinetDocument(id: UUID(), title: "Акт выполненных работ за май", kind: .act, date: .daysAgo(3), requiresSignature: true),
            CabinetDocument(id: UUID(), title: "Счет на сопровождение", kind: .invoice, date: .daysAgo(7), requiresSignature: false),
            CabinetDocument(id: UUID(), title: "Отчет по SLA", kind: .report, date: .daysAgo(12), requiresSignature: false)
        ],
        invoices: [
            Invoice(id: UUID(), number: "HG-2026-0521", amount: 148_000, dueDate: .daysFromNow(4), status: .pending),
            Invoice(id: UUID(), number: "HG-2026-0418", amount: 96_500, dueDate: .daysAgo(18), status: .paid),
            Invoice(id: UUID(), number: "HG-2026-0310", amount: 112_000, dueDate: .daysAgo(48), status: .paid)
        ],
        notifications: [
            CabinetNotification(id: UUID(), title: "Документ ожидает подписи", message: "Дополнительное соглашение №4 доступно в разделе документов.", date: .daysAgo(0), isUnread: true),
            CabinetNotification(id: UUID(), title: "Обновлен статус заявки", message: "Заявка по обновлению 1С переведена в статус ожидания клиента.", date: .daysAgo(1), isUnread: true),
            CabinetNotification(id: UUID(), title: "Назначен менеджер", message: "Ваш персональный менеджер: Мария Волкова.", date: .daysAgo(6), isUnread: false)
        ]
    )
}

extension Date {
    static func daysAgo(_ value: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: -value, to: Date()) ?? Date()
    }

    static func daysFromNow(_ value: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: value, to: Date()) ?? Date()
    }
}
