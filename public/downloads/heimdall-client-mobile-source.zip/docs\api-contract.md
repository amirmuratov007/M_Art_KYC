# HEIMDALL Mobile API Contract

Base URL:

- Production: `https://api.heimdall-group.ru/v1`
- Staging: `https://staging-api.heimdall-group.ru/v1`

Authentication:

- Mobile app sends `POST /auth/login`.
- API returns short-lived `accessToken` and `refreshToken`.
- Mobile app sends `Authorization: Bearer <accessToken>` for protected endpoints.
- Tokens are stored with `expo-secure-store` on iOS/Android and localStorage only for web preview.

## Endpoints

### `POST /auth/login`

Request:

```json
{
  "email": "client@heimdall-group.ru",
  "password": "string"
}
```

Response:

```json
{
  "accessToken": "jwt",
  "refreshToken": "jwt-or-random-token",
  "expiresAt": "2026-05-21T18:00:00.000Z",
  "clientId": "meridian-capital-group"
}
```

### `GET /client/dashboard`

Returns client metrics, notifications, and active checks.

### `GET /client/reports`

Returns PDF report metadata.

### `GET /client/reports/:reportId/download-url`

Returns a short-lived signed URL for PDF download.

### `GET /client/signals`

Returns risk signal feed.

### `GET /site/content`

Returns public website content mirrored inside the mobile app. This endpoint should be backed by the website CMS or publishing system.

Response:

```json
[
  {
    "id": "strategic-due-diligence",
    "category": "Publication",
    "title": {
      "en": "Strategic Due Diligence: Beyond Registry Checks",
      "ru": "Стратегический Due Diligence: за пределами реестровых проверок"
    },
    "excerpt": {
      "en": "How corporate intelligence helps boards identify hidden ownership and sanctions exposure.",
      "ru": "Как корпоративная разведка помогает выявлять скрытое владение и санкционную экспозицию."
    },
    "date": {
      "en": "21 May 2026",
      "ru": "21 мая 2026"
    },
    "readTime": {
      "en": "7 min read",
      "ru": "7 минут"
    },
    "url": "https://heimdall-group.ru/publications/strategic-due-diligence",
    "tags": [
      {
        "en": "Due diligence",
        "ru": "Due diligence"
      }
    ]
  }
]
```

### `POST /client/check-requests`

Request:

```json
{
  "type": "Counterparty Review",
  "subject": "Northbridge Supply LLC",
  "jurisdiction": "UAE",
  "urgency": "Priority",
  "comment": "Please review ownership and sanctions exposure."
}
```

Response:

```json
{
  "requestId": "REQ-20260521-001",
  "status": "accepted"
}
```

## Website Integration Notes

The website should expose the API above from the same customer identity domain used by the client web cabinet. The analyst/admin dashboard can write checks, reports, and signals to the same backend. Mobile clients should never read directly from website pages or scrape cabinet data.

Publications and news should come from the website CMS through `GET /site/content`, so the app mirrors the site narrative without duplicating editorial work.
