import SwiftUI

struct DocumentsView: View {
    let documents: [CabinetDocument]

    var body: some View {
        NavigationStack {
            List {
                ForEach(documents) { document in
                    Card {
                        HStack(spacing: 14) {
                            Image(systemName: document.icon)
                                .font(.title2)
                                .foregroundStyle(HeimdallTheme.accent)
                                .frame(width: 34)

                            VStack(alignment: .leading, spacing: 5) {
                                Text(document.title)
                                    .font(.headline)
                                    .foregroundStyle(HeimdallTheme.ink)
                                Text("\(document.kind.rawValue) · \(document.date.shortRu)")
                                    .font(.subheadline)
                                    .foregroundStyle(HeimdallTheme.muted)
                            }

                            Spacer()

                            if document.requiresSignature {
                                StatusPill(text: "Подписать", color: HeimdallTheme.gold)
                            }
                        }
                    }
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(HeimdallTheme.background)
            .navigationTitle("Документы")
        }
    }
}

private extension CabinetDocument {
    var icon: String {
        switch kind {
        case .contract:
            return "doc.text"
        case .act:
            return "checkmark.seal"
        case .invoice:
            return "rublesign.square"
        case .report:
            return "chart.bar.doc.horizontal"
        }
    }
}
