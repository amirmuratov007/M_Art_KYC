import React from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import type { RootStackParamList } from "../App";
import RiskBadge from "../components/RiskBadge";
import StatusBadge from "../components/StatusBadge";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { localize, t } from "../data/i18n";
import { colors, screenStyles } from "./screenStyles";

type Props = NativeStackScreenProps<RootStackParamList, "CheckDetail">;

export default function CheckDetailScreen({ route }: Props) {
  const { language } = useLocalization();
  const { checks, getReportDownloadUrl } = useAppData();
  const copy = t[language];
  const check = checks.find((item) => item.id === route.params.checkId) ?? checks[0];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.checkObject}</Text>
      <Text style={screenStyles.title}>{localize(check.subject, language)}</Text>
      <Text style={[screenStyles.muted, { marginTop: 8 }]}>{localize(check.type, language)}</Text>

      <View style={styles.scorePanel}>
        <View>
          <Text style={styles.scoreLabel}>{copy.riskScore}</Text>
          <Text style={styles.score}>{check.score}/100</Text>
        </View>
        <View style={styles.badges}>
          <StatusBadge status={check.status} />
          <RiskBadge risk={check.risk} />
        </View>
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.keyFindings}</Text>
      <View style={styles.panel}>
        {check.keyFindings.map((finding) => (
          <View key={finding.en} style={styles.findingRow}>
            <Ionicons color={colors.gold} name="scan-outline" size={16} />
            <Text style={styles.finding}>{localize(finding, language)}</Text>
          </View>
        ))}
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.timeline}</Text>
      <View style={styles.panel}>
        {check.timeline.map((event, index) => (
          <View key={`${event.label.en}-${event.date.en}`} style={styles.timelineRow}>
            <View style={styles.timelineRail}>
              <View style={styles.timelineDot} />
              {index < check.timeline.length - 1 ? <View style={styles.timelineLine} /> : null}
            </View>
            <View style={styles.timelineCopy}>
              <Text style={styles.timelineLabel}>{localize(event.label, language)}</Text>
              <Text style={styles.timelineDate}>{localize(event.date, language)}</Text>
            </View>
          </View>
        ))}
      </View>

      <Text style={screenStyles.sectionTitle}>{copy.analystRecommendation}</Text>
      <View style={styles.recommendationPanel}>
        <Text style={styles.recommendation}>{localize(check.recommendation, language)}</Text>
        <Text style={styles.analyst}>{copy.responsibleAnalyst}: {localize(check.analyst, language)}</Text>
      </View>

      <View style={styles.actions}>
        <Pressable
          onPress={async () => {
            await getReportDownloadUrl(check.id);
            Alert.alert(copy.downloadAlertTitle, copy.downloadAlertBody);
          }}
          style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}
        >
          <Text style={styles.primaryText}>{copy.downloadReport}</Text>
        </Pressable>
        <Pressable
          onPress={() => Alert.alert(copy.clarificationAlertTitle, copy.clarificationAlertBody)}
          style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]}
        >
          <Text style={styles.secondaryText}>{copy.requestClarification}</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  actions: {
    gap: 12,
    marginTop: 18
  },
  analyst: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 12
  },
  badges: {
    alignItems: "flex-end",
    gap: 8
  },
  finding: {
    color: "#CBD5E1",
    flex: 1,
    fontSize: 13,
    lineHeight: 20
  },
  findingRow: {
    flexDirection: "row",
    gap: 10,
    paddingVertical: 9
  },
  panel: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    padding: 16
  },
  pressed: {
    opacity: 0.84
  },
  primaryButton: {
    alignItems: "center",
    backgroundColor: colors.blue,
    borderRadius: 16,
    paddingVertical: 15
  },
  primaryText: {
    color: colors.background,
    fontSize: 15,
    fontWeight: "900"
  },
  recommendation: {
    color: colors.text,
    fontSize: 15,
    lineHeight: 22
  },
  recommendationPanel: {
    backgroundColor: "rgba(214, 168, 79, 0.1)",
    borderColor: "rgba(214, 168, 79, 0.22)",
    borderRadius: 20,
    borderWidth: 1,
    padding: 16
  },
  score: {
    color: colors.gold,
    fontSize: 42,
    fontWeight: "900",
    marginTop: 6
  },
  scoreLabel: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "900",
    textTransform: "uppercase"
  },
  scorePanel: {
    alignItems: "center",
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(56, 189, 248, 0.14)",
    borderRadius: 24,
    borderWidth: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 18,
    padding: 18
  },
  secondaryButton: {
    alignItems: "center",
    backgroundColor: "rgba(8, 17, 31, 0.8)",
    borderColor: "rgba(148, 163, 184, 0.2)",
    borderRadius: 16,
    borderWidth: 1,
    paddingVertical: 15
  },
  secondaryText: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "900"
  },
  timelineCopy: {
    flex: 1,
    paddingBottom: 16
  },
  timelineDate: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4
  },
  timelineDot: {
    backgroundColor: colors.blue,
    borderRadius: 999,
    height: 10,
    width: 10
  },
  timelineLabel: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "800"
  },
  timelineLine: {
    backgroundColor: "rgba(56, 189, 248, 0.2)",
    flex: 1,
    marginVertical: 4,
    width: 1
  },
  timelineRail: {
    alignItems: "center",
    marginRight: 12,
    width: 14
  },
  timelineRow: {
    flexDirection: "row",
    minHeight: 52
  }
});
