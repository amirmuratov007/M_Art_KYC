import React from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAppData } from "../data/AppDataContext";
import { localize, t } from "../data/i18n";
import { useLocalization } from "../data/LocalizationContext";
import type { Report } from "../data/mockData";
import RiskBadge from "./RiskBadge";

type Props = {
  report: Report;
};

export default function ReportCard({ report }: Props) {
  const { language } = useLocalization();
  const { getReportDownloadUrl } = useAppData();
  const copy = t[language];

  const openReport = async () => {
    await getReportDownloadUrl(report.id);
    Alert.alert(copy.openPdf, copy.downloadAlertBody);
  };

  return (
    <View style={styles.card}>
      <View style={styles.row}>
        <Ionicons color="#38BDF8" name="document-text-outline" size={24} />
        <View style={styles.content}>
          <Text style={styles.title}>{localize(report.title, language)}</Text>
          <Text style={styles.meta}>{localize(report.date, language)} · {localize(report.type, language)}</Text>
        </View>
      </View>
      <View style={styles.bottomRow}>
        <RiskBadge risk={report.risk} />
        <Pressable
          onPress={openReport}
          style={({ pressed }) => [styles.button, pressed && styles.pressed]}
        >
          <Text style={styles.buttonText}>{copy.openPdf}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bottomRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 16
  },
  button: {
    backgroundColor: "rgba(56, 189, 248, 0.14)",
    borderColor: "rgba(56, 189, 248, 0.26)",
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10
  },
  buttonText: {
    color: "#7DD3FC",
    fontSize: 12,
    fontWeight: "900"
  },
  card: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 14,
    padding: 16
  },
  content: {
    flex: 1
  },
  meta: {
    color: "#94A3B8",
    fontSize: 12,
    marginTop: 4
  },
  pressed: {
    opacity: 0.82
  },
  row: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 12
  },
  title: {
    color: "#F8FAFC",
    fontSize: 16,
    fontWeight: "800",
    lineHeight: 22
  }
});
