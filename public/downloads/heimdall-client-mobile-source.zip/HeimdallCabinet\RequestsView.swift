import SwiftUI

struct RequestsView: View {
    let requests: [CabinetRequest]
    @State private var showsNewRequest = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(requests) { request in
                    RequestRow(request: request)
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(HeimdallTheme.background)
            .navigationTitle("Заявки")
            .toolbar {
                Button {
                    showsNewRequest = true
                } label: {
                    Image(systemName: "plus")
                }
                .accessibilityLabel("Создать заявку")
            }
            .sheet(isPresented: $showsNewRequest) {
                NewRequestView()
            }
        }
    }
}

struct RequestRow: View {
    let request: CabinetRequest

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(request.title)
                            .font(.headline)
                            .foregroundStyle(HeimdallTheme.ink)
                        Text(request.service)
                            .font(.subheadline)
                            .foregroundStyle(HeimdallTheme.muted)
                    }
                    Spacer()
                    StatusPill(text: request.status.rawValue, color: request.status.color)
                }

                Text(request.comment)
                    .font(.footnote)
                    .foregroundStyle(HeimdallTheme.muted)

                Text("Обновлено \(request.updatedAt.shortRu)")
                    .font(.caption)
                    .foregroundStyle(HeimdallTheme.muted)
            }
        }
    }
}

extension CabinetRequest.Status {
    var color: Color {
        switch self {
        case .new:
            return .blue
        case .inProgress:
            return HeimdallTheme.accent
        case .waiting:
            return HeimdallTheme.gold
        case .done:
            return .green
        }
    }
}
