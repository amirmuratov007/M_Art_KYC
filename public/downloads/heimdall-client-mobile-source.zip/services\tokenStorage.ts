import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";
import type { ClientSession } from "../types/api";

const SESSION_KEY = "heimdall.client.session";

export async function saveSession(session: ClientSession): Promise<void> {
  const value = JSON.stringify(session);
  if (Platform.OS === "web") {
    window.localStorage.setItem(SESSION_KEY, value);
    return;
  }
  await SecureStore.setItemAsync(SESSION_KEY, value, {
    keychainService: "heimdall-client-session"
  });
}

export async function getSession(): Promise<ClientSession | null> {
  const value =
    Platform.OS === "web"
      ? window.localStorage.getItem(SESSION_KEY)
      : await SecureStore.getItemAsync(SESSION_KEY, {
          keychainService: "heimdall-client-session"
        });

  if (!value) {
    return null;
  }

  try {
    return JSON.parse(value) as ClientSession;
  } catch {
    await clearSession();
    return null;
  }
}

export async function clearSession(): Promise<void> {
  if (Platform.OS === "web") {
    window.localStorage.removeItem(SESSION_KEY);
    return;
  }
  await SecureStore.deleteItemAsync(SESSION_KEY, {
    keychainService: "heimdall-client-session"
  });
}
