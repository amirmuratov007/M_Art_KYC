import React from "react";
import { ScrollView, Text } from "react-native";
import SiteContentCard from "../components/SiteContentCard";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { t } from "../data/i18n";
import { screenStyles } from "./screenStyles";

export default function SiteContentScreen() {
  const { language } = useLocalization();
  const { siteContent } = useAppData();
  const copy = t[language];
  const [featured, ...latest] = siteContent;

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.siteEyebrow}</Text>
      <Text style={screenStyles.title}>{copy.siteTitle}</Text>
      <Text style={[screenStyles.muted, { marginBottom: 18, marginTop: 8 }]}>{copy.siteCopy}</Text>

      {featured ? (
        <>
          <Text style={screenStyles.sectionTitle}>{copy.featuredSiteContent}</Text>
          <SiteContentCard item={featured} featured />
        </>
      ) : null}

      <Text style={screenStyles.sectionTitle}>{copy.allSiteContent}</Text>
      {latest.map((item) => (
        <SiteContentCard key={item.id} item={item} />
      ))}
    </ScrollView>
  );
}
