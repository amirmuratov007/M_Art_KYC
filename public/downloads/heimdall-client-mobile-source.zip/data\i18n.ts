import type { CheckStatus, Language, LocalizedText, RiskLevel, SignalSeverity } from "./mockData";

export const t = {
  en: {
    loginBrand: "Corporate Intelligence Group",
    clientAccess: "Client access",
    loginCopy: "Secure intelligence workspace for active support contracts.",
    email: "Email",
    password: "Password",
    signIn: "Sign in",
    clientOnly: "Client access only",
    accessDenied: "Access denied",
    enterCredentials: "Please enter client credentials.",
    tabs: {
      Dashboard: "Dashboard",
      Checks: "Checks",
      Reports: "Reports",
      Signals: "Signals",
      Site: "Site",
      Request: "Request"
    },
    checkDetailTitle: "Check detail",
    support: "Support",
    dashboardEyebrow: "HEIMDALL intelligence",
    contractStatus: "Contract status",
    monthlyChecks: "Monthly checks",
    monthlyChecksHelper: "Included in current support cycle",
    usedChecks: "Used checks",
    usedChecksHelper: "Available balance remains active",
    riskIndex: "Risk index",
    riskIndexHelper: "Portfolio-level exposure score",
    activeChecks: "Active checks",
    completedReports: "completed reports",
    priorityChecks: "Priority checks",
    latestNotifications: "Latest notifications",
    checksEyebrow: "Active verification queue",
    checksTitle: "Checks",
    checksCopy:
      "Counterparty, candidate, ownership, sanctions, and vendor reviews handled by the HEIMDALL analyst desk.",
    deadline: "Deadline",
    analyst: "Analyst",
    open: "Open",
    checkObject: "Check object",
    riskScore: "Risk score",
    keyFindings: "Key findings",
    timeline: "Timeline",
    analystRecommendation: "Analyst recommendation",
    responsibleAnalyst: "Responsible analyst",
    downloadReport: "Download report",
    requestClarification: "Request clarification",
    downloadAlertTitle: "Download report",
    downloadAlertBody: "Report download will be connected to HEIMDALL API",
    clarificationAlertTitle: "Clarification requested",
    clarificationAlertBody: "Your question will be routed to the assigned analyst.",
    reportsEyebrow: "Intelligence archive",
    reportsTitle: "Reports",
    reportsCopy: "PDF reports prepared for Meridian Capital Group under the active support contract.",
    openPdf: "Open PDF",
    signalsEyebrow: "Monitoring feed",
    signalsTitle: "Risk signals",
    signalsCopy:
      "Litigation, sanctions exposure, reputation, ownership, and adverse media signals requiring client attention.",
    siteEyebrow: "From HEIMDALL website",
    siteTitle: "Insights",
    siteCopy:
      "Publications, news, analytical notes, and press updates from HEIMDALL Intelligence Group.",
    featuredSiteContent: "Featured",
    allSiteContent: "Latest from site",
    openOnSite: "Open on site",
    siteLinkAlertTitle: "Website link",
    siteLinkAlertBody: "This article will open from the HEIMDALL website after web linking is connected.",
    siteCategories: {
      Publication: "Publication",
      News: "News",
      Insight: "Insight",
      Press: "Press"
    },
    recommendedAction: "Recommended action",
    requestEyebrow: "New intelligence task",
    requestTitle: "Request check",
    requestCopy: "Submit a new verification request to the HEIMDALL analyst team.",
    checkType: "Check type",
    subject: "Company or full name",
    subjectPlaceholder: "Enter subject",
    jurisdiction: "Jurisdiction",
    jurisdictionPlaceholder: "Country or region",
    urgency: "Urgency",
    comment: "Comment",
    commentPlaceholder: "Add context for the analyst team",
    attachFiles: "Attach files",
    mockUpload: "Mock upload for first release",
    submitRequest: "Submit request",
    missingInfoTitle: "Missing information",
    missingInfoBody: "Please add a company or person name and jurisdiction.",
    requestSubmittedTitle: "Request submitted",
    requestSubmittedBody: "Request submitted to HEIMDALL analyst team",
    fileUploadTitle: "File upload",
    fileUploadBody: "File upload will be connected to HEIMDALL API",
    urgencyOptions: ["Standard", "Priority", "Critical"],
    supportEyebrow: "Client support contract",
    startingFrom: "Starting from",
    perMonth: "per month",
    included: "Included",
    analystContact: "Analyst contact",
    contactHeimdall: "Contact HEIMDALL",
    contactAlertTitle: "Contact HEIMDALL",
    contactAlertBody: "Your message will be routed to the HEIMDALL analyst desk.",
    includedItems: [
      "Dedicated analyst contact for active intelligence requests",
      "Counterparty, vendor, candidate, and UBO checks",
      "Sanctions exposure monitoring and escalation notes",
      "Monthly risk brief with portfolio-level recommendations",
      "Secure report archive prepared for API integration"
    ],
    statuses: {
      New: "New",
      "In progress": "In progress",
      "Analyst review": "Analyst review",
      Completed: "Completed"
    },
    risks: {
      Low: "Low risk",
      Medium: "Medium risk",
      High: "High risk"
    },
    severities: {
      Low: "Low",
      Medium: "Medium",
      High: "High",
      Critical: "Critical"
    }
  },
  ru: {
    loginBrand: "Группа корпоративной разведки",
    clientAccess: "Клиентский доступ",
    loginCopy: "Защищённое пространство разведывательной аналитики для действующих договоров сопровождения.",
    email: "Email",
    password: "Пароль",
    signIn: "Войти",
    clientOnly: "Только для клиентов",
    accessDenied: "Доступ отклонён",
    enterCredentials: "Введите клиентские учётные данные.",
    tabs: {
      Dashboard: "Главная",
      Checks: "Проверки",
      Reports: "Отчёты",
      Signals: "Сигналы",
      Site: "Сайт",
      Request: "Запрос"
    },
    checkDetailTitle: "Детали проверки",
    support: "Сопровождение",
    dashboardEyebrow: "Разведка HEIMDALL",
    contractStatus: "Статус договора",
    monthlyChecks: "Проверок в месяц",
    monthlyChecksHelper: "Включено в текущий цикл сопровождения",
    usedChecks: "Использовано",
    usedChecksHelper: "Оставшийся лимит активен",
    riskIndex: "Индекс риска",
    riskIndexHelper: "Портфельная оценка экспозиции",
    activeChecks: "Активные проверки",
    completedReports: "готовых отчётов",
    priorityChecks: "Приоритетные проверки",
    latestNotifications: "Последние уведомления",
    checksEyebrow: "Активная очередь проверок",
    checksTitle: "Проверки",
    checksCopy:
      "Проверки контрагентов, кандидатов, владельцев, санкций и поставщиков ведёт аналитическая группа HEIMDALL.",
    deadline: "Срок",
    analyst: "Аналитик",
    open: "Открыть",
    checkObject: "Объект проверки",
    riskScore: "Оценка риска",
    keyFindings: "Ключевые выводы",
    timeline: "Ход проверки",
    analystRecommendation: "Рекомендация аналитика",
    responsibleAnalyst: "Ответственный аналитик",
    downloadReport: "Скачать отчёт",
    requestClarification: "Запросить уточнение",
    downloadAlertTitle: "Скачать отчёт",
    downloadAlertBody: "Загрузка отчёта будет подключена к HEIMDALL API",
    clarificationAlertTitle: "Уточнение запрошено",
    clarificationAlertBody: "Ваш вопрос будет передан ответственному аналитику.",
    reportsEyebrow: "Архив разведки",
    reportsTitle: "Отчёты",
    reportsCopy: "PDF-отчёты, подготовленные для Meridian Capital Group в рамках активного договора сопровождения.",
    openPdf: "Открыть PDF",
    signalsEyebrow: "Лента мониторинга",
    signalsTitle: "Риск-сигналы",
    signalsCopy:
      "Судебные, санкционные, репутационные, структурные и медийные сигналы, требующие внимания клиента.",
    siteEyebrow: "С сайта HEIMDALL",
    siteTitle: "Материалы",
    siteCopy:
      "Публикации, новости, аналитические заметки и пресс-материалы HEIMDALL Intelligence Group.",
    featuredSiteContent: "Главный материал",
    allSiteContent: "Последнее с сайта",
    openOnSite: "Открыть на сайте",
    siteLinkAlertTitle: "Ссылка на сайт",
    siteLinkAlertBody: "Материал будет открываться с сайта HEIMDALL после подключения web linking.",
    siteCategories: {
      Publication: "Публикация",
      News: "Новость",
      Insight: "Аналитика",
      Press: "Пресс-релиз"
    },
    recommendedAction: "Рекомендуемое действие",
    requestEyebrow: "Новая задача для аналитиков",
    requestTitle: "Запрос проверки",
    requestCopy: "Отправьте новую задачу на проверку аналитической группе HEIMDALL.",
    checkType: "Тип проверки",
    subject: "Компания или ФИО",
    subjectPlaceholder: "Введите объект проверки",
    jurisdiction: "Юрисдикция",
    jurisdictionPlaceholder: "Страна или регион",
    urgency: "Срочность",
    comment: "Комментарий",
    commentPlaceholder: "Добавьте контекст для аналитиков",
    attachFiles: "Прикрепить файлы",
    mockUpload: "Mock-загрузка для первой версии",
    submitRequest: "Отправить запрос",
    missingInfoTitle: "Недостаточно данных",
    missingInfoBody: "Добавьте название компании или ФИО и юрисдикцию.",
    requestSubmittedTitle: "Запрос отправлен",
    requestSubmittedBody: "Запрос отправлен аналитической группе HEIMDALL",
    fileUploadTitle: "Загрузка файлов",
    fileUploadBody: "Загрузка файлов будет подключена к HEIMDALL API",
    urgencyOptions: ["Стандартная", "Приоритетная", "Критическая"],
    supportEyebrow: "Договор клиентского сопровождения",
    startingFrom: "Стоимость от",
    perMonth: "в месяц",
    included: "Что входит",
    analystContact: "Контакт с аналитиком",
    contactHeimdall: "Связаться с HEIMDALL",
    contactAlertTitle: "Связаться с HEIMDALL",
    contactAlertBody: "Ваше сообщение будет передано аналитической группе HEIMDALL.",
    includedItems: [
      "Выделенный аналитик для активных разведывательных запросов",
      "Проверки контрагентов, поставщиков, кандидатов и КБВ",
      "Мониторинг санкционной экспозиции и эскалационные заметки",
      "Ежемесячный риск-бриф с портфельными рекомендациями",
      "Защищённый архив отчётов, подготовленный к интеграции с API"
    ],
    statuses: {
      New: "Новая",
      "In progress": "В работе",
      "Analyst review": "Аналитическая проверка",
      Completed: "Завершена"
    },
    risks: {
      Low: "Низкий риск",
      Medium: "Средний риск",
      High: "Высокий риск"
    },
    severities: {
      Low: "Низкая",
      Medium: "Средняя",
      High: "Высокая",
      Critical: "Критическая"
    }
  }
} as const;

export function localize(value: LocalizedText, language: Language): string {
  return value[language];
}

export function statusLabel(status: CheckStatus, language: Language): string {
  return t[language].statuses[status];
}

export function riskLabel(risk: RiskLevel, language: Language): string {
  return t[language].risks[risk];
}

export function severityLabel(severity: SignalSeverity, language: Language): string {
  return t[language].severities[severity];
}
