import React from "react";
import { ScrollView, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";
import type { AppNavigation } from "../App";
import CheckCard from "../components/CheckCard";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { t } from "../data/i18n";
import { screenStyles } from "./screenStyles";

export default function ChecksScreen() {
  const navigation = useNavigation<AppNavigation>();
  const { language } = useLocalization();
  const { checks } = useAppData();
  const copy = t[language];

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.checksEyebrow}</Text>
      <Text style={screenStyles.title}>{copy.checksTitle}</Text>
      <Text style={[screenStyles.muted, { marginBottom: 18, marginTop: 8 }]}>
        {copy.checksCopy}
      </Text>
      {checks.map((check) => (
        <CheckCard
          check={check}
          key={check.id}
          onOpen={() => navigation.navigate("CheckDetail", { checkId: check.id })}
        />
      ))}
    </ScrollView>
  );
}
