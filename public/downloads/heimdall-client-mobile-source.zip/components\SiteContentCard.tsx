import React from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useLocalization } from "../data/LocalizationContext";
import { localize, t } from "../data/i18n";
import type { SiteContentItem } from "../data/mockData";

type Props = {
  item: SiteContentItem;
  featured?: boolean;
};

export default function SiteContentCard({ item, featured = false }: Props) {
  const { language } = useLocalization();
  const copy = t[language];

  return (
    <View style={[styles.card, featured && styles.featured]}>
      <View style={styles.topRow}>
        <View style={styles.categoryPill}>
          <Text style={styles.categoryText}>{copy.siteCategories[item.category]}</Text>
        </View>
        <Text style={styles.date}>{localize(item.date, language)}</Text>
      </View>

      <Text style={[styles.title, featured && styles.featuredTitle]}>{localize(item.title, language)}</Text>
      <Text style={styles.excerpt}>{localize(item.excerpt, language)}</Text>

      <View style={styles.tagRow}>
        {item.tags.map((tag) => (
          <View key={tag.en} style={styles.tag}>
            <Text style={styles.tagText}>{localize(tag, language)}</Text>
          </View>
        ))}
      </View>

      <View style={styles.bottomRow}>
        <Text style={styles.readTime}>{localize(item.readTime, language)}</Text>
        <Pressable
          onPress={() => Alert.alert(copy.siteLinkAlertTitle, copy.siteLinkAlertBody)}
          style={({ pressed }) => [styles.button, pressed && styles.pressed]}
        >
          <Text style={styles.buttonText}>{copy.openOnSite}</Text>
          <Ionicons color="#050816" name="open-outline" size={15} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bottomRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 16
  },
  button: {
    alignItems: "center",
    backgroundColor: "#38BDF8",
    borderRadius: 14,
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: 13,
    paddingVertical: 10
  },
  buttonText: {
    color: "#050816",
    fontSize: 12,
    fontWeight: "900"
  },
  card: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 14,
    padding: 16
  },
  categoryPill: {
    backgroundColor: "rgba(214, 168, 79, 0.16)",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6
  },
  categoryText: {
    color: "#F6D88A",
    fontSize: 11,
    fontWeight: "900",
    textTransform: "uppercase"
  },
  date: {
    color: "#94A3B8",
    fontSize: 12,
    fontWeight: "800"
  },
  excerpt: {
    color: "#CBD5E1",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 10
  },
  featured: {
    borderColor: "rgba(56, 189, 248, 0.22)",
    padding: 18,
    shadowColor: "#000",
    shadowOffset: { height: 16, width: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 26
  },
  featuredTitle: {
    fontSize: 22,
    lineHeight: 29
  },
  pressed: {
    opacity: 0.84
  },
  readTime: {
    color: "#94A3B8",
    fontSize: 12,
    fontWeight: "800"
  },
  tag: {
    backgroundColor: "rgba(56, 189, 248, 0.1)",
    borderRadius: 999,
    paddingHorizontal: 9,
    paddingVertical: 5
  },
  tagRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 7,
    marginTop: 14
  },
  tagText: {
    color: "#7DD3FC",
    fontSize: 11,
    fontWeight: "800"
  },
  title: {
    color: "#F8FAFC",
    fontSize: 17,
    fontWeight: "900",
    lineHeight: 23,
    marginTop: 14
  },
  topRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between"
  }
});
