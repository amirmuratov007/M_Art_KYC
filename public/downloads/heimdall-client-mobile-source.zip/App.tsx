import "react-native-gesture-handler";

import React, { useEffect, useState } from "react";
import { Alert, Image, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { NavigationContainer, NavigatorScreenParams } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator, NativeStackScreenProps } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";

import { AppDataProvider, useAppData } from "./data/AppDataContext";
import { LocalizationContext, useLocalization } from "./data/LocalizationContext";
import { localize, t } from "./data/i18n";
import { checks } from "./data/mockData";
import { heimdallApi } from "./services/heimdallApi";
import { saveSession } from "./services/tokenStorage";
import DashboardScreen from "./screens/DashboardScreen";
import ChecksScreen from "./screens/ChecksScreen";
import CheckDetailScreen from "./screens/CheckDetailScreen";
import ReportsScreen from "./screens/ReportsScreen";
import RiskSignalsScreen from "./screens/RiskSignalsScreen";
import SiteContentScreen from "./screens/SiteContentScreen";
import RequestCheckScreen from "./screens/RequestCheckScreen";
import SupportScreen from "./screens/SupportScreen";

export type RootStackParamList = {
  Splash: undefined;
  LanguageSelect: undefined;
  Login: undefined;
  Main: NavigatorScreenParams<TabParamList> | undefined;
  CheckDetail: { checkId: string };
  Support: undefined;
};

export type TabParamList = {
  Dashboard: undefined;
  Checks: undefined;
  Reports: undefined;
  Signals: undefined;
  Site: undefined;
  Request: undefined;
};

export type AppNavigation = NativeStackScreenProps<RootStackParamList>["navigation"];

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();
const heimdallEmblem = require("./assets/heimdall-static-emblem.jpg");

const theme = {
  background: "#050816",
  panel: "#08111F",
  blue: "#38BDF8",
  gold: "#D6A84F",
  text: "#F8FAFC",
  muted: "#94A3B8"
};

function SplashScreen({ navigation }: NativeStackScreenProps<RootStackParamList, "Splash">) {
  useEffect(() => {
    const timer = setTimeout(() => navigation.replace("LanguageSelect"), 1300);
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.splashRoot}>
      <StatusBar style="light" />
      <View style={styles.splashGlow} />
      <Image source={heimdallEmblem} style={styles.splashEmblem} resizeMode="contain" />
      <View style={styles.splashLine} />
    </View>
  );
}

function LanguageSelectScreen({ navigation }: NativeStackScreenProps<RootStackParamList, "LanguageSelect">) {
  const { language, setLanguage } = useLocalization();

  const chooseLanguage = (nextLanguage: "en" | "ru") => {
    setLanguage(nextLanguage);
    navigation.replace("Login");
  };

  return (
    <View style={styles.languageRoot}>
      <StatusBar style="light" />
      <View style={styles.loginGlow} />
      <View style={styles.languageHeader}>
        <Image source={heimdallEmblem} style={styles.headerEmblem} resizeMode="contain" />
        <Text style={styles.brandSubtitle}>
          {language === "ru" ? "Выберите язык интерфейса" : "Choose interface language"}
        </Text>
      </View>

      <View style={styles.languagePanel}>
        <Pressable
          onPress={() => chooseLanguage("en")}
          style={({ pressed }) => [styles.languageCard, pressed && styles.pressed]}
        >
          <Text style={styles.languageCardTitle}>English</Text>
          <Text style={styles.languageCardCopy}>Corporate intelligence workspace in English.</Text>
          <Ionicons color={theme.blue} name="arrow-forward-circle-outline" size={26} />
        </Pressable>

        <Pressable
          onPress={() => chooseLanguage("ru")}
          style={({ pressed }) => [styles.languageCard, pressed && styles.pressed]}
        >
          <Text style={styles.languageCardTitle}>Русский</Text>
          <Text style={styles.languageCardCopy}>Клиентское пространство корпоративной разведки на русском языке.</Text>
          <Ionicons color={theme.blue} name="arrow-forward-circle-outline" size={26} />
        </Pressable>
      </View>
    </View>
  );
}

function LoginScreen({ navigation }: NativeStackScreenProps<RootStackParamList, "Login">) {
  const { language, setLanguage } = useLocalization();
  const { refresh } = useAppData();
  const copy = t[language];
  const [email, setEmail] = useState("client@heimdall-group.ru");
  const [password, setPassword] = useState("••••••••");

  const handleSignIn = async () => {
    if (!email || !password) {
      Alert.alert(copy.accessDenied, copy.enterCredentials);
      return;
    }
    try {
      const session = await heimdallApi.login({ email, password });
      await saveSession(session);
      await refresh();
      navigation.replace("Main", { screen: "Dashboard" });
    } catch {
      Alert.alert(copy.accessDenied, copy.enterCredentials);
    }
  };

  return (
    <View style={styles.loginRoot}>
      <View style={styles.loginGlow} />
      <StatusBar style="light" />
      <SafeAreaView style={styles.loginSafe}>
        <View style={styles.brandMark}>
          <Image source={heimdallEmblem} style={styles.headerEmblem} resizeMode="contain" />
          <Text style={styles.brandSubtitle}>{copy.loginBrand}</Text>
        </View>

        <View style={styles.loginPanel}>
          <Pressable onPress={() => navigation.replace("LanguageSelect")} style={styles.changeLanguageButton}>
            <Ionicons color={theme.gold} name="language-outline" size={16} />
            <Text style={styles.changeLanguageText}>{language === "ru" ? "Изменить язык" : "Change language"}</Text>
          </Pressable>
          <Text style={styles.loginHeading}>{copy.clientAccess}</Text>
          <Text style={styles.loginCopy}>{copy.loginCopy}</Text>

          <TextInput
            autoCapitalize="none"
            keyboardType="email-address"
            onChangeText={setEmail}
            placeholder={copy.email}
            placeholderTextColor="#64748B"
            style={styles.input}
            value={email}
          />
          <TextInput
            onChangeText={setPassword}
            placeholder={copy.password}
            placeholderTextColor="#64748B"
            secureTextEntry
            style={styles.input}
            value={password}
          />

          <Pressable onPress={handleSignIn} style={({ pressed }) => [styles.signInButton, pressed && styles.pressed]}>
            <Text style={styles.signInText}>{copy.signIn}</Text>
            <Ionicons color="#050816" name="arrow-forward" size={18} />
          </Pressable>
          <Text style={styles.clientOnly}>{copy.clientOnly}</Text>
        </View>
      </SafeAreaView>
    </View>
  );
}

function MainTabs() {
  const { language } = useLocalization();
  const copy = t[language];
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.blue,
        tabBarInactiveTintColor: theme.muted,
        tabBarStyle: styles.tabBar,
        tabBarLabel: copy.tabs[route.name],
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ color, size }) => {
          const icons: Record<keyof TabParamList, keyof typeof Ionicons.glyphMap> = {
            Dashboard: "grid-outline",
            Checks: "shield-checkmark-outline",
            Reports: "document-text-outline",
            Signals: "pulse-outline",
            Site: "newspaper-outline",
            Request: "add-circle-outline"
          };
          return <Ionicons color={color} name={icons[route.name]} size={size} />;
        }
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Checks" component={ChecksScreen} />
      <Tab.Screen name="Reports" component={ReportsScreen} />
      <Tab.Screen name="Signals" component={RiskSignalsScreen} />
      <Tab.Screen name="Site" component={SiteContentScreen} />
      <Tab.Screen name="Request" component={RequestCheckScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  const [language, setLanguage] = useState<"en" | "ru">("en");

  return (
    <LocalizationContext.Provider value={{ language, setLanguage }}>
      <AppDataProvider>
        <NavigationContainer>
          <Stack.Navigator
            screenOptions={{
              contentStyle: { backgroundColor: theme.background },
              headerBackTitleVisible: false,
              headerStyle: { backgroundColor: theme.background },
              headerTintColor: theme.text,
              headerTitleStyle: { fontWeight: "700" }
            }}
          >
            <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />
            <Stack.Screen name="LanguageSelect" component={LanguageSelectScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
            <Stack.Screen
              name="CheckDetail"
              component={CheckDetailScreen}
              options={({ route }) => ({
                title: localize(
                  checks.find((check) => check.id === route.params.checkId)?.type ?? {
                    en: t.en.checkDetailTitle,
                    ru: t.ru.checkDetailTitle
                  },
                  language
                )
              })}
            />
            <Stack.Screen name="Support" component={SupportScreen} options={{ title: t[language].support }} />
          </Stack.Navigator>
        </NavigationContainer>
      </AppDataProvider>
    </LocalizationContext.Provider>
  );
}

const styles = StyleSheet.create({
  brandLine: {
    backgroundColor: theme.gold,
    borderRadius: 999,
    height: 3,
    marginBottom: 18,
    width: 62
  },
  brandMark: {
    marginTop: 48
  },
  brandSubtitle: {
    color: theme.muted,
    fontSize: 14,
    letterSpacing: 1.2,
    marginTop: 8,
    textTransform: "uppercase"
  },
  brandTitle: {
    color: theme.text,
    fontSize: 40,
    fontWeight: "800",
    letterSpacing: 3
  },
  changeLanguageButton: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "rgba(214, 168, 79, 0.1)",
    borderColor: "rgba(214, 168, 79, 0.2)",
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: "row",
    gap: 7,
    marginBottom: 18,
    paddingHorizontal: 11,
    paddingVertical: 7
  },
  changeLanguageText: {
    color: "#F6D88A",
    fontSize: 12,
    fontWeight: "900"
  },
  clientOnly: {
    color: theme.muted,
    fontSize: 12,
    marginTop: 18,
    textAlign: "center",
    textTransform: "uppercase"
  },
  input: {
    backgroundColor: "rgba(8, 17, 31, 0.82)",
    borderColor: "rgba(148, 163, 184, 0.16)",
    borderRadius: 16,
    borderWidth: 1,
    color: theme.text,
    fontSize: 15,
    marginTop: 14,
    paddingHorizontal: 16,
    paddingVertical: 15
  },
  loginCopy: {
    color: theme.muted,
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 10
  },
  loginHeading: {
    color: theme.text,
    fontSize: 24,
    fontWeight: "800",
    marginBottom: 8
  },
  loginPanel: {
    backgroundColor: "rgba(8, 17, 31, 0.72)",
    borderColor: "rgba(56, 189, 248, 0.16)",
    borderRadius: 28,
    borderWidth: 1,
    marginTop: 42,
    padding: 22,
    shadowColor: "#000",
    shadowOffset: { height: 18, width: 0 },
    shadowOpacity: 0.36,
    shadowRadius: 28
  },
  loginRoot: {
    backgroundColor: theme.background,
    flex: 1
  },
  languageCard: {
    alignItems: "center",
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(56, 189, 248, 0.18)",
    borderRadius: 24,
    borderWidth: 1,
    flexDirection: "row",
    gap: 14,
    padding: 18,
    shadowColor: "#000",
    shadowOffset: { height: 18, width: 0 },
    shadowOpacity: 0.28,
    shadowRadius: 26
  },
  languageCardCopy: {
    color: theme.muted,
    flex: 1,
    fontSize: 13,
    lineHeight: 19
  },
  languageCardTitle: {
    color: theme.text,
    fontSize: 20,
    fontWeight: "900",
    minWidth: 86
  },
  languageHeader: {
    marginBottom: 34,
    width: "100%"
  },
  languagePanel: {
    gap: 14,
    width: "100%"
  },
  languageRoot: {
    backgroundColor: theme.background,
    flex: 1,
    justifyContent: "center",
    padding: 22
  },
  headerEmblem: {
    height: 180,
    marginBottom: 8,
    width: "100%"
  },
  loginGlow: {
    backgroundColor: "rgba(56, 189, 248, 0.08)",
    borderRadius: 260,
    height: 420,
    position: "absolute",
    right: -180,
    top: -150,
    width: 420
  },
  loginSafe: {
    flex: 1,
    justifyContent: "center",
    padding: 22
  },
  pressed: {
    opacity: 0.82,
    transform: [{ scale: 0.99 }]
  },
  signInButton: {
    alignItems: "center",
    backgroundColor: theme.blue,
    borderRadius: 16,
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    marginTop: 18,
    paddingVertical: 16
  },
  signInText: {
    color: theme.background,
    fontSize: 16,
    fontWeight: "800"
  },
  splashGlow: {
    backgroundColor: "rgba(56, 189, 248, 0.09)",
    borderRadius: 320,
    height: 520,
    position: "absolute",
    top: -210,
    width: 520
  },
  splashLine: {
    backgroundColor: theme.gold,
    borderRadius: 999,
    height: 3,
    marginTop: 30,
    width: 82
  },
  splashEmblem: {
    height: 280,
    width: "100%"
  },
  splashRoot: {
    alignItems: "center",
    backgroundColor: theme.background,
    flex: 1,
    justifyContent: "center",
    overflow: "hidden",
    padding: 24
  },
  tabBar: {
    backgroundColor: "#060B18",
    borderTopColor: "rgba(148, 163, 184, 0.14)",
    height: 82,
    paddingBottom: 14,
    paddingTop: 8
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: "700"
  }
});
