# Heimdall Cabinet Windows

Windows-версия личного кабинета Heimdall.

В папке есть две версии:

- `ClassicProgram.cs` + `build.ps1` - сборка, которая работает здесь без установки .NET SDK.
- `.csproj`-версия под .NET 6 SDK - для нормальной разработки в Visual Studio.

## Запуск

```powershell
.\HeimdallCabinet.Windows\build.ps1
.\HeimdallCabinet.Windows\bin\HeimdallCabinet.exe
```

## Сборка exe без SDK

```powershell
.\HeimdallCabinet.Windows\build.ps1
```

После сборки exe будет в:

```text
HeimdallCabinet.Windows\bin\HeimdallCabinet.exe
```

Демо-вход:

- E-mail: `client@company.ru`
- Пароль: `demo`

Папка `HeimdallCabinet` с iOS SwiftUI-версией сохранена без изменений.
