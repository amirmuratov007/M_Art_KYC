using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeimdallCabinet.Windows;

public sealed class MockHeimdallApi : IHeimdallApi
{
    private readonly CabinetSnapshot _snapshot = DemoData.CreateSnapshot();

    public async Task<CabinetSnapshot> SignInAsync(string email, string password)
    {
        await Task.Delay(250);
        if (!email.Contains('@') || password.Length < 4)
        {
            throw new HeimdallApiException("Проверьте e-mail и пароль.");
        }

        return _snapshot;
    }

    public async Task<CabinetSnapshot> RefreshCabinetAsync()
    {
        await Task.Delay(150);
        return _snapshot;
    }

    public async Task<CabinetRequest> CreateRequestAsync(string title, string service, string comment)
    {
        await Task.Delay(150);
        var request = new CabinetRequest(
            Guid.NewGuid(),
            title,
            service,
            RequestStatus.New,
            DateTime.Now,
            string.IsNullOrWhiteSpace(comment) ? "Заявка зарегистрирована." : comment);

        _snapshot.Requests.Insert(0, request);
        _snapshot.Summary = _snapshot.Summary with
        {
            ActiveRequests = _snapshot.Summary.ActiveRequests + 1
        };

        return request;
    }

    public async Task MarkNotificationsReadAsync()
    {
        await Task.Delay(100);
        _snapshot.Notifications = _snapshot.Notifications
            .Select(item => item with { IsUnread = false })
            .ToList();
    }
}

internal static class DemoData
{
    public static CabinetSnapshot CreateSnapshot()
    {
        return new CabinetSnapshot(
            new UserProfile(
                Guid.NewGuid(),
                "Александр Мурадов",
                "ООО «Северный Контур»",
                "Клиент",
                "client@company.ru",
                "+7 999 000-45-12",
                "Мария Волкова"),
            new DashboardSummary(4, 2, 1, 1280),
            new List<CabinetRequest>
            {
                new(Guid.NewGuid(), "Настройка интеграции с CRM", "Автоматизация продаж", RequestStatus.InProgress, DateTime.Now.AddDays(-1), "Специалист проверяет обмен заказами и остатками."),
                new(Guid.NewGuid(), "Обновление 1С ERP", "Внедрение и обновление 1С", RequestStatus.Waiting, DateTime.Now.AddDays(-2), "Нужно согласовать окно работ."),
                new(Guid.NewGuid(), "Отчет по складу", "Финансовый учет", RequestStatus.Done, DateTime.Now.AddDays(-5), "Отчет передан ответственному менеджеру."),
                new(Guid.NewGuid(), "Проверка ЭДО", "Бухгалтерия и кадровый учет", RequestStatus.New, DateTime.Now, "Заявка зарегистрирована.")
            },
            new List<CabinetDocument>
            {
                new(Guid.NewGuid(), "Дополнительное соглашение №4", DocumentKind.Contract, DateTime.Now.AddDays(-1), true),
                new(Guid.NewGuid(), "Акт выполненных работ за май", DocumentKind.Act, DateTime.Now.AddDays(-3), true),
                new(Guid.NewGuid(), "Счет на сопровождение", DocumentKind.Invoice, DateTime.Now.AddDays(-7), false),
                new(Guid.NewGuid(), "Отчет по SLA", DocumentKind.Report, DateTime.Now.AddDays(-12), false)
            },
            new List<Invoice>
            {
                new(Guid.NewGuid(), "HG-2026-0521", 148000m, DateTime.Now.AddDays(4), InvoiceStatus.Pending),
                new(Guid.NewGuid(), "HG-2026-0418", 96500m, DateTime.Now.AddDays(-18), InvoiceStatus.Paid),
                new(Guid.NewGuid(), "HG-2026-0310", 112000m, DateTime.Now.AddDays(-48), InvoiceStatus.Paid)
            },
            new List<CabinetNotification>
            {
                new(Guid.NewGuid(), "Документ ожидает подписи", "Дополнительное соглашение №4 доступно в разделе документов.", DateTime.Now, true),
                new(Guid.NewGuid(), "Обновлен статус заявки", "Заявка по обновлению 1С переведена в статус ожидания клиента.", DateTime.Now.AddDays(-1), true),
                new(Guid.NewGuid(), "Назначен менеджер", "Ваш персональный менеджер: Мария Волкова.", DateTime.Now.AddDays(-6), false)
            });
    }
}
