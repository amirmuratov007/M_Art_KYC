import Foundation

@MainActor
final class SessionStore: ObservableObject {
    enum State: Equatable {
        case signedOut
        case loading
        case signedIn(CabinetSnapshot)
        case failed(String)
    }

    @Published private(set) var state: State = .signedOut

    private let api: HeimdallAPI

    init(api: HeimdallAPI) {
        self.api = api
    }

    var snapshot: CabinetSnapshot? {
        if case let .signedIn(snapshot) = state {
            return snapshot
        }
        return nil
    }

    func signIn(email: String, password: String) async {
        state = .loading
        do {
            state = .signedIn(try await api.signIn(email: email, password: password))
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func signOut() {
        state = .signedOut
    }

    func refresh() async {
        guard case .signedIn = state else { return }
        do {
            state = .signedIn(try await api.refreshCabinet())
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func createRequest(title: String, service: String, comment: String) async {
        guard var snapshot else { return }
        do {
            let request = try await api.createRequest(title: title, service: service, comment: comment)
            snapshot.requests.insert(request, at: 0)
            snapshot.summary.activeRequests += 1
            state = .signedIn(snapshot)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func markNotificationsRead() async {
        guard var snapshot else { return }
        do {
            try await api.markNotificationsRead()
            snapshot.notifications = snapshot.notifications.map {
                var item = $0
                item.isUnread = false
                return item
            }
            state = .signedIn(snapshot)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}
