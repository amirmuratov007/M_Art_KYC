import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var session: SessionStore

    let snapshot: CabinetSnapshot

    @State private var showsNewRequest = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    greeting
                    summaryGrid
                    managerCard
                    recentRequests
                    notifications
                }
                .padding(16)
            }
            .background(HeimdallTheme.background)
            .navigationTitle("Кабинет")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showsNewRequest = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Создать заявку")
                }
            }
            .refreshable {
                await session.refresh()
            }
            .sheet(isPresented: $showsNewRequest) {
                NewRequestView()
            }
        }
    }

    private var greeting: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Здравствуйте, \(snapshot.profile.fullName)")
                .font(.title2.weight(.bold))
                .foregroundStyle(HeimdallTheme.ink)
            Text(snapshot.profile.company)
                .font(.subheadline)
                .foregroundStyle(HeimdallTheme.muted)
        }
    }

    private var summaryGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            SummaryTile(title: "Заявки", value: "\(snapshot.summary.activeRequests)", icon: "tray.full", color: HeimdallTheme.accent)
            SummaryTile(title: "На подпись", value: "\(snapshot.summary.documentsToSign)", icon: "signature", color: HeimdallTheme.gold)
            SummaryTile(title: "К оплате", value: "\(snapshot.summary.unpaidInvoices)", icon: "rublesign.circle", color: HeimdallTheme.danger)
            SummaryTile(title: "Баллы", value: "\(snapshot.summary.loyaltyPoints)", icon: "star", color: Color.blue)
        }
    }

    private var managerCard: some View {
        Card {
            HStack(spacing: 14) {
                Image(systemName: "person.crop.circle.badge.checkmark")
                    .font(.system(size: 34))
                    .foregroundStyle(HeimdallTheme.accent)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Ваш менеджер")
                        .font(.caption)
                        .foregroundStyle(HeimdallTheme.muted)
                    Text(snapshot.profile.managerName)
                        .font(.headline)
                        .foregroundStyle(HeimdallTheme.ink)
                    Text("Ответит по заявкам, документам и оплатам")
                        .font(.footnote)
                        .foregroundStyle(HeimdallTheme.muted)
                }
                Spacer()
                Button {} label: {
                    Image(systemName: "message")
                }
                .buttonStyle(.bordered)
                .tint(HeimdallTheme.accent)
            }
        }
    }

    private var recentRequests: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Последние заявки", action: "Все")
            ForEach(snapshot.requests.prefix(3)) { request in
                RequestRow(request: request)
            }
        }
    }

    private var notifications: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(title: "Уведомления", action: nil)
            ForEach(snapshot.notifications.prefix(2)) { item in
                NotificationRow(notification: item)
            }
        }
    }
}

private struct SummaryTile: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(color)
                Text(value)
                    .font(.title.weight(.bold))
                    .foregroundStyle(HeimdallTheme.ink)
                Text(title)
                    .font(.caption)
                    .foregroundStyle(HeimdallTheme.muted)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

struct SectionHeader: View {
    let title: String
    let action: String?

    var body: some View {
        HStack {
            Text(title)
                .font(.headline)
                .foregroundStyle(HeimdallTheme.ink)
            Spacer()
            if let action {
                Text(action)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(HeimdallTheme.accent)
            }
        }
        .padding(.top, 4)
    }
}
