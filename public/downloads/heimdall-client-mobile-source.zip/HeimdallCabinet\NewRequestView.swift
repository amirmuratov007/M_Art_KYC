import SwiftUI

struct NewRequestView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var session: SessionStore

    @State private var title = ""
    @State private var service = "Автоматизация продаж"
    @State private var comment = ""
    @State private var isSubmitting = false

    private let services = [
        "Автоматизация продаж",
        "Внедрение и обновление 1С",
        "Финансовый учет",
        "Бухгалтерия и кадровый учет",
        "B2B-портал"
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("Тема") {
                    TextField("Например, нужна выгрузка остатков", text: $title)
                }

                Section("Услуга") {
                    Picker("Услуга", selection: $service) {
                        ForEach(services, id: \.self) { service in
                            Text(service).tag(service)
                        }
                    }
                }

                Section("Комментарий") {
                    TextEditor(text: $comment)
                        .frame(minHeight: 120)
                }
            }
            .navigationTitle("Новая заявка")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isSubmitting ? "Отправка" : "Создать") {
                        submit()
                    }
                    .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSubmitting)
                }
            }
        }
    }

    private func submit() {
        isSubmitting = true
        Task {
            await session.createRequest(title: title, service: service, comment: comment)
            isSubmitting = false
            dismiss()
        }
    }
}
