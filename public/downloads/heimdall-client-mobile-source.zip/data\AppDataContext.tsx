import React, { createContext, ReactNode, useContext, useMemo, useState } from "react";
import { heimdallApi } from "../services/heimdallApi";
import type { RequestCheckPayload, RequestCheckResponse } from "../types/api";
import {
  checks as initialChecks,
  client,
  notifications,
  reports as initialReports,
  signals as initialSignals,
  siteContent as initialSiteContent
} from "./mockData";
import type { Check, Report, Signal, SiteContentItem } from "./mockData";

type AppDataContextValue = {
  client: typeof client;
  notifications: typeof notifications;
  checks: Check[];
  reports: Report[];
  signals: Signal[];
  siteContent: SiteContentItem[];
  isLoading: boolean;
  refresh: () => Promise<void>;
  submitCheckRequest: (payload: RequestCheckPayload) => Promise<RequestCheckResponse>;
  getReportDownloadUrl: (reportId: string) => Promise<string>;
};

const AppDataContext = createContext<AppDataContextValue | undefined>(undefined);

export function AppDataProvider({ children }: { children: ReactNode }) {
  const [checks, setChecks] = useState<Check[]>(initialChecks);
  const [reports, setReports] = useState<Report[]>(initialReports);
  const [signals, setSignals] = useState<Signal[]>(initialSignals);
  const [siteContent, setSiteContent] = useState<SiteContentItem[]>(initialSiteContent);
  const [isLoading, setIsLoading] = useState(false);

  const refresh = async () => {
    setIsLoading(true);
    try {
      const [dashboardPayload, reportsPayload, signalsPayload, siteContentPayload] = await Promise.all([
        heimdallApi.getDashboard(),
        heimdallApi.getReports(),
        heimdallApi.getSignals(),
        heimdallApi.getSiteContent()
      ]);
      setChecks(dashboardPayload.checks);
      setReports(reportsPayload);
      setSignals(signalsPayload);
      setSiteContent(siteContentPayload);
    } finally {
      setIsLoading(false);
    }
  };

  const value = useMemo<AppDataContextValue>(
    () => ({
      client,
      notifications,
      checks,
      reports,
      signals,
      siteContent,
      isLoading,
      refresh,
      submitCheckRequest: heimdallApi.submitCheckRequest,
      getReportDownloadUrl: heimdallApi.getReportDownloadUrl
    }),
    [checks, isLoading, reports, signals, siteContent]
  );

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  const value = useContext(AppDataContext);
  if (!value) {
    throw new Error("useAppData must be used within AppDataProvider");
  }
  return value;
}
