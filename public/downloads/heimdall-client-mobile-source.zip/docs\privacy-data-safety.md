# Privacy And Data Safety Notes

HEIMDALL handles sensitive business intelligence data. Before public release, publish a privacy policy at:

`https://heimdall-group.ru/privacy`

## Data Categories

Expected categories:

- Account information: email, client company, support plan.
- Business content: check requests, comments, uploaded files, report metadata.
- Risk intelligence: check statuses, findings, signals, recommendations.
- Diagnostics: crash logs and performance data if Sentry or another tool is added.

## Security Requirements

- Use HTTPS only.
- Store auth tokens in SecureStore on mobile.
- Use short-lived signed URLs for PDFs.
- Keep uploaded files in private object storage.
- Enforce tenant isolation by client ID on every backend endpoint.
- Log access to reports and check details.
- Provide account deletion/contact process through HEIMDALL support.

## Google Play Data Safety

Likely declarations:

- Data is collected for app functionality and account management.
- Data is encrypted in transit.
- Users cannot create public accounts.
- Data deletion is available by contacting HEIMDALL support.

Final declarations must match the production backend and analytics stack exactly.
