import { checks, client, notifications, reports, signals, siteContent } from "../data/mockData";
import type {
  ClientSession,
  DashboardPayload,
  HeimdallApi,
  LoginRequest,
  RequestCheckPayload,
  RequestCheckResponse
} from "../types/api";

const delay = (ms = 280) => new Promise((resolve) => setTimeout(resolve, ms));

export const mockHeimdallApi: HeimdallApi = {
  async login(request: LoginRequest): Promise<ClientSession> {
    await delay();
    return {
      accessToken: `mock-access-token:${request.email}`,
      refreshToken: "mock-refresh-token",
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 8).toISOString(),
      clientId: "meridian-capital-group"
    };
  },

  async getDashboard(): Promise<DashboardPayload> {
    await delay();
    return {
      client,
      notifications,
      checks
    };
  },

  async getChecks() {
    await delay();
    return checks;
  },

  async getCheck(checkId: string) {
    await delay(120);
    return checks.find((check) => check.id === checkId);
  },

  async getReports() {
    await delay();
    return reports;
  },

  async getSignals() {
    await delay();
    return signals;
  },

  async getSiteContent() {
    await delay();
    return siteContent;
  },

  async submitCheckRequest(payload: RequestCheckPayload): Promise<RequestCheckResponse> {
    await delay();
    return {
      requestId: `REQ-${Date.now()}-${payload.subject.slice(0, 3).toUpperCase()}`,
      status: "accepted"
    };
  },

  async getReportDownloadUrl(reportId: string): Promise<string> {
    await delay(120);
    return `heimdall://reports/${reportId}`;
  }
};
