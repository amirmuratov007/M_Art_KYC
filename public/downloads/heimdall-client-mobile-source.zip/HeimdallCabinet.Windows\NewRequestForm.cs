using System.Drawing;
using System.Windows.Forms;

namespace HeimdallCabinet.Windows;

public sealed class NewRequestForm : Form
{
    private readonly TextBox _titleBox = new();
    private readonly ComboBox _serviceBox = new();
    private readonly TextBox _commentBox = new();

    public NewRequestForm()
    {
        Text = "Новая заявка";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(460, 420);
        BackColor = Theme.Background;

        var form = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            RowCount = 8,
            ColumnCount = 1,
            BackColor = Theme.Background
        };

        _titleBox.Font = Theme.BodyFont;
        _titleBox.Height = 32;

        _serviceBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _serviceBox.Font = Theme.BodyFont;
        _serviceBox.Items.AddRange(new object[]
        {
            "Автоматизация продаж",
            "Внедрение и обновление 1С",
            "Финансовый учет",
            "Бухгалтерия и кадровый учет",
            "B2B-портал"
        });
        _serviceBox.SelectedIndex = 0;

        _commentBox.Font = Theme.BodyFont;
        _commentBox.Multiline = true;
        _commentBox.Height = 110;

        var actions = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.RightToLeft,
            Dock = DockStyle.Fill,
            Height = 48
        };

        var create = Theme.Button("Создать");
        create.Width = 120;
        create.Click += (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(RequestTitle))
            {
                MessageBox.Show(this, "Введите тему заявки.", "Heimdall", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        };

        var cancel = Theme.Button("Отмена", Color.FromArgb(90, 100, 112));
        cancel.Width = 120;
        cancel.Click += (_, _) =>
        {
            DialogResult = DialogResult.Cancel;
            Close();
        };

        actions.Controls.Add(create);
        actions.Controls.Add(cancel);

        form.Controls.Add(Theme.Label("Тема", Theme.SmallFont, Theme.Muted));
        form.Controls.Add(_titleBox);
        form.Controls.Add(Theme.Label("Услуга", Theme.SmallFont, Theme.Muted));
        form.Controls.Add(_serviceBox);
        form.Controls.Add(Theme.Label("Комментарий", Theme.SmallFont, Theme.Muted));
        form.Controls.Add(_commentBox);
        form.Controls.Add(actions);

        Controls.Add(form);
    }

    public string RequestTitle => _titleBox.Text.Trim();
    public string Service => _serviceBox.SelectedItem?.ToString() ?? "Автоматизация продаж";
    public string Comment => _commentBox.Text.Trim();
}
