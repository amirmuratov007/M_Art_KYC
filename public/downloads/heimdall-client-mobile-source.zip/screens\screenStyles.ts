import { StyleSheet } from "react-native";

export const colors = {
  background: "#050816",
  panel: "#08111F",
  blue: "#38BDF8",
  gold: "#D6A84F",
  text: "#F8FAFC",
  muted: "#94A3B8"
};

export const screenStyles = StyleSheet.create({
  container: {
    backgroundColor: colors.background,
    flex: 1
  },
  content: {
    padding: 18,
    paddingBottom: 110
  },
  eyebrow: {
    color: colors.gold,
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 1.4,
    marginBottom: 8,
    textTransform: "uppercase"
  },
  headerRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 18
  },
  muted: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 21
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 20,
    fontWeight: "900",
    marginBottom: 14,
    marginTop: 8
  },
  title: {
    color: colors.text,
    fontSize: 28,
    fontWeight: "900",
    lineHeight: 34
  }
});
