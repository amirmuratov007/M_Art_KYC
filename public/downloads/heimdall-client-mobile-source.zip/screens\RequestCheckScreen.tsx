import React, { useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAppData } from "../data/AppDataContext";
import { useLocalization } from "../data/LocalizationContext";
import { localize, t } from "../data/i18n";
import { checkTypes } from "../data/mockData";
import { colors, screenStyles } from "./screenStyles";

export default function RequestCheckScreen() {
  const { language } = useLocalization();
  const { submitCheckRequest } = useAppData();
  const copy = t[language];
  const [selectedTypeIndex, setSelectedTypeIndex] = useState(0);
  const [urgencyIndex, setUrgencyIndex] = useState(0);
  const [subject, setSubject] = useState("");
  const [jurisdiction, setJurisdiction] = useState("");
  const [comment, setComment] = useState("");

  const submit = async () => {
    if (!subject.trim() || !jurisdiction.trim()) {
      Alert.alert(copy.missingInfoTitle, copy.missingInfoBody);
      return;
    }
    await submitCheckRequest({
      type: checkTypes[selectedTypeIndex].en,
      subject,
      jurisdiction,
      urgency: copy.urgencyOptions[urgencyIndex],
      comment
    });
    Alert.alert(copy.requestSubmittedTitle, copy.requestSubmittedBody);
    setSubject("");
    setJurisdiction("");
    setComment("");
  };

  return (
    <ScrollView style={screenStyles.container} contentContainerStyle={screenStyles.content}>
      <Text style={screenStyles.eyebrow}>{copy.requestEyebrow}</Text>
      <Text style={screenStyles.title}>{copy.requestTitle}</Text>
      <Text style={[screenStyles.muted, { marginBottom: 18, marginTop: 8 }]}>
        {copy.requestCopy}
      </Text>

      <Text style={styles.label}>{copy.checkType}</Text>
      <View style={styles.optionGrid}>
        {checkTypes.map((type, index) => (
          <Pressable
            key={type.en}
            onPress={() => setSelectedTypeIndex(index)}
            style={[styles.option, selectedTypeIndex === index && styles.optionSelected]}
          >
            <Text style={[styles.optionText, selectedTypeIndex === index && styles.optionTextSelected]}>
              {localize(type, language)}
            </Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.label}>{copy.subject}</Text>
      <TextInput
        onChangeText={setSubject}
        placeholder={copy.subjectPlaceholder}
        placeholderTextColor="#64748B"
        style={styles.input}
        value={subject}
      />

      <Text style={styles.label}>{copy.jurisdiction}</Text>
      <TextInput
        onChangeText={setJurisdiction}
        placeholder={copy.jurisdictionPlaceholder}
        placeholderTextColor="#64748B"
        style={styles.input}
        value={jurisdiction}
      />

      <Text style={styles.label}>{copy.urgency}</Text>
      <View style={styles.segment}>
        {copy.urgencyOptions.map((item, index) => (
          <Pressable
            key={item}
            onPress={() => setUrgencyIndex(index)}
            style={[styles.segmentItem, urgencyIndex === index && styles.segmentSelected]}
          >
            <Text style={[styles.segmentText, urgencyIndex === index && styles.segmentTextSelected]}>{item}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.label}>{copy.comment}</Text>
      <TextInput
        multiline
        onChangeText={setComment}
        placeholder={copy.commentPlaceholder}
        placeholderTextColor="#64748B"
        style={[styles.input, styles.textArea]}
        textAlignVertical="top"
        value={comment}
      />

      <Pressable
        onPress={() => Alert.alert(copy.fileUploadTitle, copy.fileUploadBody)}
        style={styles.uploadBox}
      >
        <Ionicons color={colors.blue} name="cloud-upload-outline" size={22} />
        <Text style={styles.uploadText}>{copy.attachFiles}</Text>
        <Text style={styles.uploadMeta}>{copy.mockUpload}</Text>
      </Pressable>

      <Pressable onPress={submit} style={({ pressed }) => [styles.submitButton, pressed && styles.pressed]}>
        <Text style={styles.submitText}>{copy.submitRequest}</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  input: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.14)",
    borderRadius: 16,
    borderWidth: 1,
    color: colors.text,
    fontSize: 15,
    marginBottom: 14,
    paddingHorizontal: 15,
    paddingVertical: 14
  },
  label: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "900",
    marginBottom: 9,
    marginTop: 8,
    textTransform: "uppercase"
  },
  option: {
    backgroundColor: "rgba(8, 17, 31, 0.74)",
    borderColor: "rgba(148, 163, 184, 0.14)",
    borderRadius: 15,
    borderWidth: 1,
    marginBottom: 8,
    paddingHorizontal: 13,
    paddingVertical: 11
  },
  optionGrid: {
    marginBottom: 10
  },
  optionSelected: {
    backgroundColor: "rgba(56, 189, 248, 0.14)",
    borderColor: "rgba(56, 189, 248, 0.32)"
  },
  optionText: {
    color: "#CBD5E1",
    fontSize: 13,
    fontWeight: "800"
  },
  optionTextSelected: {
    color: "#7DD3FC"
  },
  pressed: {
    opacity: 0.84
  },
  segment: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.14)",
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: "row",
    marginBottom: 14,
    padding: 4
  },
  segmentItem: {
    alignItems: "center",
    borderRadius: 12,
    flex: 1,
    paddingVertical: 10
  },
  segmentSelected: {
    backgroundColor: "rgba(214, 168, 79, 0.16)"
  },
  segmentText: {
    color: colors.muted,
    fontSize: 12,
    fontWeight: "900"
  },
  segmentTextSelected: {
    color: "#F6D88A"
  },
  submitButton: {
    alignItems: "center",
    backgroundColor: colors.blue,
    borderRadius: 16,
    marginTop: 18,
    paddingVertical: 16
  },
  submitText: {
    color: colors.background,
    fontSize: 15,
    fontWeight: "900"
  },
  textArea: {
    minHeight: 110
  },
  uploadBox: {
    alignItems: "center",
    backgroundColor: "rgba(56, 189, 248, 0.08)",
    borderColor: "rgba(56, 189, 248, 0.22)",
    borderRadius: 18,
    borderStyle: "dashed",
    borderWidth: 1,
    padding: 18
  },
  uploadMeta: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4
  },
  uploadText: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "900",
    marginTop: 8
  }
});
