using System.Drawing;
using System.Windows.Forms;

namespace HeimdallCabinet.Windows;

internal static class Theme
{
    public static readonly Color Background = Color.FromArgb(245, 247, 249);
    public static readonly Color Surface = Color.White;
    public static readonly Color Ink = Color.FromArgb(18, 24, 33);
    public static readonly Color Muted = Color.FromArgb(91, 101, 115);
    public static readonly Color Accent = Color.FromArgb(0, 102, 98);
    public static readonly Color Gold = Color.FromArgb(189, 143, 61);
    public static readonly Color Danger = Color.FromArgb(194, 46, 46);
    public static readonly Color Border = Color.FromArgb(222, 228, 234);

    public static readonly Font TitleFont = new("Segoe UI", 20f, FontStyle.Bold);
    public static readonly Font HeadingFont = new("Segoe UI", 13f, FontStyle.Bold);
    public static readonly Font BodyFont = new("Segoe UI", 10f, FontStyle.Regular);
    public static readonly Font SmallFont = new("Segoe UI", 9f, FontStyle.Regular);

    public static Label Label(string text, Font? font = null, Color? color = null)
    {
        return new Label
        {
            AutoSize = true,
            Text = text,
            Font = font ?? BodyFont,
            ForeColor = color ?? Ink,
            Margin = new Padding(0, 0, 0, 6)
        };
    }

    public static Button Button(string text, Color? color = null)
    {
        return new Button
        {
            Text = text,
            AutoSize = false,
            Height = 40,
            FlatStyle = FlatStyle.Flat,
            BackColor = color ?? Accent,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 10f, FontStyle.Bold),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 6, 0, 6)
        };
    }

    public static Panel Card()
    {
        return new Panel
        {
            BackColor = Surface,
            Padding = new Padding(16),
            Margin = new Padding(0, 0, 0, 12),
            BorderStyle = BorderStyle.FixedSingle
        };
    }
}
