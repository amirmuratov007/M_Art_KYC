$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePath = Join-Path $projectDir "ClassicProgram.cs"
$binDir = Join-Path $projectDir "bin"
$outputPath = Join-Path $binDir "HeimdallCabinet.exe"

if (-not (Test-Path $binDir)) {
    New-Item -ItemType Directory -Path $binDir | Out-Null
}

if (Test-Path $outputPath) {
    Remove-Item $outputPath
}

$source = [System.IO.File]::ReadAllText($sourcePath, [System.Text.Encoding]::UTF8)

Add-Type `
    -TypeDefinition $source `
    -ReferencedAssemblies "System.Windows.Forms", "System.Drawing", "System.Core" `
    -OutputAssembly $outputPath `
    -OutputType WindowsApplication

Write-Host "Built: $outputPath"
