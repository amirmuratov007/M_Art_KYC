import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var session: SessionStore

    let profile: UserProfile
    let notifications: [CabinetNotification]

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 14) {
                            ZStack {
                                Circle()
                                    .fill(HeimdallTheme.accent.opacity(0.13))
                                Text(initials)
                                    .font(.title2.weight(.bold))
                                    .foregroundStyle(HeimdallTheme.accent)
                            }
                            .frame(width: 64, height: 64)

                            VStack(alignment: .leading, spacing: 4) {
                                Text(profile.fullName)
                                    .font(.headline)
                                    .foregroundStyle(HeimdallTheme.ink)
                                Text(profile.company)
                                    .font(.subheadline)
                                    .foregroundStyle(HeimdallTheme.muted)
                                Text(profile.role)
                                    .font(.caption)
                                    .foregroundStyle(HeimdallTheme.muted)
                            }
                        }

                        Divider()

                        InfoLine(icon: "envelope", title: "E-mail", value: profile.email)
                        InfoLine(icon: "phone", title: "Телефон", value: profile.phone)
                        InfoLine(icon: "person.text.rectangle", title: "Менеджер", value: profile.managerName)
                    }
                    .padding(.vertical, 8)
                }

                Section("Уведомления") {
                    ForEach(notifications) { notification in
                        NotificationRow(notification: notification)
                    }
                    Button("Отметить все прочитанными") {
                        Task { await session.markNotificationsRead() }
                    }
                    .foregroundStyle(HeimdallTheme.accent)
                }

                Section {
                    Button(role: .destructive) {
                        session.signOut()
                    } label: {
                        Label("Выйти", systemImage: "rectangle.portrait.and.arrow.right")
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(HeimdallTheme.background)
            .navigationTitle("Профиль")
        }
    }

    private var initials: String {
        profile.fullName
            .split(separator: " ")
            .prefix(2)
            .compactMap(\.first)
            .map(String.init)
            .joined()
    }
}

private struct InfoLine: View {
    let icon: String
    let title: String
    let value: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(HeimdallTheme.accent)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(HeimdallTheme.muted)
                Text(value)
                    .font(.subheadline)
                    .foregroundStyle(HeimdallTheme.ink)
            }
        }
    }
}

struct NotificationRow: View {
    let notification: CabinetNotification

    var body: some View {
        Card {
            HStack(alignment: .top, spacing: 12) {
                Circle()
                    .fill(notification.isUnread ? HeimdallTheme.accent : Color.clear)
                    .frame(width: 8, height: 8)
                    .padding(.top, 7)

                VStack(alignment: .leading, spacing: 5) {
                    Text(notification.title)
                        .font(.headline)
                        .foregroundStyle(HeimdallTheme.ink)
                    Text(notification.message)
                        .font(.footnote)
                        .foregroundStyle(HeimdallTheme.muted)
                    Text(notification.date.shortRu)
                        .font(.caption)
                        .foregroundStyle(HeimdallTheme.muted)
                }
            }
        }
    }
}
