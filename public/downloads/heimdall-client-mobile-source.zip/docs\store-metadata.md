# Store Metadata

## App Identity

- App name: HEIMDALL
- Subtitle: Corporate Intelligence Platform
- Bundle ID / Package: `ru.heimdallgroup.client`
- Category: Business
- Support URL: `https://heimdall-group.ru/support`
- Privacy Policy URL: `https://heimdall-group.ru/privacy`
- Marketing URL: `https://heimdall-group.ru`

## Short Description

Secure client workspace for HEIMDALL business intelligence, risk checks, reports, and analyst support.

## Full Description

HEIMDALL is a premium corporate intelligence platform for companies under an active business support contract. Clients can review active checks, monitor risk signals, access intelligence reports, request new checks, and communicate with the analyst team through a secure mobile workspace.

The first release supports counterparty intelligence, candidate screening, beneficial ownership review, sanctions screening, vendor review, risk signal monitoring, PDF report access, and new check requests.

## Review Account

Create a dedicated non-production review account before submission:

- Email: `review@heimdall-group.ru`
- Password: provide only in App Store Connect / Google Play Console review notes
- Client profile: Meridian Capital Group demo workspace

## App Review Notes

This is a client-only corporate intelligence workspace. Use the supplied review account to access demo data. Report downloads and file upload can be connected to production HEIMDALL API endpoints; current internal build may use mock/staging data depending on the selected build profile.

## Keywords

corporate intelligence, risk management, compliance, sanctions screening, counterparty review, due diligence, business support
