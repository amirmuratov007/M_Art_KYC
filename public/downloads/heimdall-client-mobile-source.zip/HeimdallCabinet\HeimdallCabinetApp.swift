import SwiftUI

@main
struct HeimdallCabinetApp: App {
    @StateObject private var session = SessionStore(api: MockHeimdallAPI())

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
        }
    }
}
