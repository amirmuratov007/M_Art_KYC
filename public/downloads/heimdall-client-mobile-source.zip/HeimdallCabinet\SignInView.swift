import SwiftUI

struct SignInView: View {
    @EnvironmentObject private var session: SessionStore

    var errorMessage: String?

    @State private var email = "client@company.ru"
    @State private var password = "demo"
    @State private var showsPassword = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.04, green: 0.09, blue: 0.10), Color(red: 0.00, green: 0.30, blue: 0.29)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 28) {
                        brand

                        VStack(alignment: .leading, spacing: 18) {
                            Text("Вход в личный кабинет")
                                .font(.title2.weight(.bold))
                                .foregroundStyle(HeimdallTheme.ink)

                            VStack(spacing: 12) {
                                TextField("E-mail", text: $email)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .textContentType(.emailAddress)
                                    .formField()

                                HStack {
                                    Group {
                                        if showsPassword {
                                            TextField("Пароль", text: $password)
                                        } else {
                                            SecureField("Пароль", text: $password)
                                        }
                                    }
                                    .textContentType(.password)

                                    Button {
                                        showsPassword.toggle()
                                    } label: {
                                        Image(systemName: showsPassword ? "eye.slash" : "eye")
                                            .foregroundStyle(HeimdallTheme.muted)
                                    }
                                    .accessibilityLabel(showsPassword ? "Скрыть пароль" : "Показать пароль")
                                }
                                .formField()
                            }

                            if let errorMessage {
                                Text(errorMessage)
                                    .font(.footnote)
                                    .foregroundStyle(HeimdallTheme.danger)
                            }

                            Button {
                                Task { await session.signIn(email: email, password: password) }
                            } label: {
                                Text("Войти")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(HeimdallTheme.accent)

                            Button("Получить доступ") {}
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(HeimdallTheme.accent)
                                .frame(maxWidth: .infinity)
                        }
                        .padding(20)
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .padding(24)
                    .padding(.top, 42)
                }
            }
        }
    }

    private var brand: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: "shield.lefthalf.filled")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(HeimdallTheme.gold)
                Text("HEIMDALL")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }

            Text("Единый доступ к заявкам, документам, оплатам и связи с менеджером.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.82))
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

private extension View {
    func formField() -> some View {
        self
            .padding(.horizontal, 14)
            .frame(height: 52)
            .background(Color.black.opacity(0.04))
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}
