import React from "react";
import { StyleSheet, Text, View } from "react-native";

type Props = {
  label: string;
  value: string | number;
  accent?: "blue" | "gold";
  helper?: string;
};

export default function MetricCard({ label, value, accent = "blue", helper }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.label}>{label}</Text>
      <Text style={[styles.value, accent === "gold" ? styles.gold : styles.blue]}>{value}</Text>
      {helper ? <Text style={styles.helper}>{helper}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  blue: {
    color: "#38BDF8"
  },
  card: {
    backgroundColor: "rgba(8, 17, 31, 0.78)",
    borderColor: "rgba(148, 163, 184, 0.13)",
    borderRadius: 20,
    borderWidth: 1,
    flex: 1,
    minHeight: 132,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { height: 14, width: 0 },
    shadowOpacity: 0.22,
    shadowRadius: 24
  },
  gold: {
    color: "#D6A84F"
  },
  helper: {
    color: "#94A3B8",
    fontSize: 12,
    lineHeight: 17,
    marginTop: 8
  },
  label: {
    color: "#94A3B8",
    fontSize: 12,
    fontWeight: "700",
    lineHeight: 17,
    textTransform: "uppercase"
  },
  value: {
    fontSize: 34,
    fontWeight: "900",
    marginTop: 12
  }
});
