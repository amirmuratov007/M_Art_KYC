export type CheckStatus = "New" | "In progress" | "Analyst review" | "Completed";
export type RiskLevel = "Low" | "Medium" | "High";
export type SignalSeverity = "Low" | "Medium" | "High" | "Critical";
export type Language = "en" | "ru";
export type LocalizedText = Record<Language, string>;
export type SiteContentCategory = "Publication" | "News" | "Insight" | "Press";

export type Check = {
  id: string;
  subject: LocalizedText;
  type: LocalizedText;
  status: CheckStatus;
  risk: RiskLevel;
  score: number;
  deadline: LocalizedText;
  analyst: LocalizedText;
  keyFindings: LocalizedText[];
  timeline: { label: LocalizedText; date: LocalizedText }[];
  recommendation: LocalizedText;
};

export type Report = {
  id: string;
  title: LocalizedText;
  date: LocalizedText;
  type: LocalizedText;
  risk: RiskLevel;
};

export type Signal = {
  id: string;
  title: LocalizedText;
  severity: SignalSeverity;
  affected: LocalizedText;
  explanation: LocalizedText;
  recommendedAction: LocalizedText;
};

export type SiteContentItem = {
  id: string;
  category: SiteContentCategory;
  title: LocalizedText;
  excerpt: LocalizedText;
  date: LocalizedText;
  readTime: LocalizedText;
  url: string;
  tags: LocalizedText[];
};

export const client = {
  company: "Meridian Capital Group",
  contractStatus: {
    en: "Active Support",
    ru: "Активное сопровождение"
  },
  plan: {
    en: "Enhanced Business Support",
    ru: "Расширенное бизнес-сопровождение"
  },
  monthlyChecksIncluded: 18,
  usedChecks: 7,
  riskIndex: 64,
  activeChecks: 5,
  completedReports: 9,
  analyst: {
    en: "Elena Volkova",
    ru: "Елена Волкова"
  },
  analystEmail: "support@heimdall-group.ru"
};

export const notifications = [
  {
    en: "Analyst review started for Northbridge Supply LLC.",
    ru: "Начата аналитическая проверка Northbridge Supply LLC."
  },
  {
    en: "Ownership change signal detected in Orion Trade network.",
    ru: "Обнаружен сигнал об изменении структуры владения Orion Trade."
  },
  {
    en: "Candidate Screening Report is ready for review.",
    ru: "Отчёт по проверке кандидата готов к просмотру."
  }
];

export const checks: Check[] = [
  {
    id: "northbridge-supply",
    subject: { en: "Northbridge Supply LLC", ru: "Northbridge Supply LLC" },
    type: { en: "Counterparty Intelligence", ru: "Разведка по контрагенту" },
    status: "Analyst review",
    risk: "High",
    score: 82,
    deadline: { en: "24 May 2026", ru: "24 мая 2026" },
    analyst: { en: "Marcus Reed", ru: "Маркус Рид" },
    keyFindings: [
      {
        en: "Two unresolved commercial litigation records in adjacent jurisdictions.",
        ru: "Два незавершённых коммерческих спора в смежных юрисдикциях."
      },
      {
        en: "Indirect supplier relationship with a sanctioned logistics operator.",
        ru: "Косвенная связь поставщика с логистическим оператором под санкционными ограничениями."
      },
      {
        en: "Recent director change without corresponding registry disclosure.",
        ru: "Недавняя смена директора без синхронного раскрытия в реестре."
      }
    ],
    timeline: [
      { label: { en: "Request accepted", ru: "Запрос принят" }, date: { en: "19 May", ru: "19 мая" } },
      { label: { en: "Registry review", ru: "Проверка реестров" }, date: { en: "20 May", ru: "20 мая" } },
      { label: { en: "Analyst review", ru: "Аналитическая проверка" }, date: { en: "21 May", ru: "21 мая" } }
    ],
    recommendation: {
      en: "Proceed only with enhanced contractual protections and final sanctions screening before signing.",
      ru: "Продолжать только при усиленной договорной защите и финальном санкционном скрининге перед подписанием."
    }
  },
  {
    id: "ilya-sorokin",
    subject: { en: "Ilya Sorokin", ru: "Илья Сорокин" },
    type: { en: "Candidate Screening", ru: "Проверка кандидата" },
    status: "Completed",
    risk: "Medium",
    score: 74,
    deadline: { en: "Completed", ru: "Завершено" },
    analyst: { en: "Sophia Laurent", ru: "София Лоран" },
    keyFindings: [
      {
        en: "Employment history is consistent across primary sources.",
        ru: "Трудовая история подтверждается основными источниками."
      },
      {
        en: "One adverse media mention requires contextual review.",
        ru: "Одна негативная публикация требует контекстной оценки."
      },
      {
        en: "No sanctions, PEP, or major litigation exposure identified.",
        ru: "Санкционные, PEP- и существенные судебные риски не выявлены."
      }
    ],
    timeline: [
      { label: { en: "Request accepted", ru: "Запрос принят" }, date: { en: "15 May", ru: "15 мая" } },
      { label: { en: "Source verification", ru: "Проверка источников" }, date: { en: "16 May", ru: "16 мая" } },
      { label: { en: "Report issued", ru: "Отчёт выпущен" }, date: { en: "18 May", ru: "18 мая" } }
    ],
    recommendation: {
      en: "Candidate can proceed to final interview with targeted questions on the disclosed media item.",
      ru: "Кандидата можно допустить к финальному интервью с адресными вопросами по выявленной публикации."
    }
  },
  {
    id: "orion-trade",
    subject: { en: "Orion Trade Beneficial Network", ru: "Бенефициарная сеть Orion Trade" },
    type: { en: "Beneficial Owner Review", ru: "Проверка бенефициаров" },
    status: "In progress",
    risk: "High",
    score: 88,
    deadline: { en: "26 May 2026", ru: "26 мая 2026" },
    analyst: { en: "Daniel Hart", ru: "Даниэль Харт" },
    keyFindings: [
      {
        en: "Layered ownership through three offshore entities.",
        ru: "Многоуровневое владение через три офшорные структуры."
      },
      {
        en: "Two nominee director patterns match prior HEIMDALL risk typologies.",
        ru: "Два признака номинальных директоров совпадают с риск-типологиями HEIMDALL."
      },
      {
        en: "Ultimate beneficial owner confirmation is still pending.",
        ru: "Подтверждение конечного бенефициара ещё ожидается."
      }
    ],
    timeline: [
      { label: { en: "Request accepted", ru: "Запрос принят" }, date: { en: "18 May", ru: "18 мая" } },
      { label: { en: "Corporate mapping", ru: "Карта корпоративных связей" }, date: { en: "20 May", ru: "20 мая" } },
      { label: { en: "UBO verification", ru: "Проверка КБВ" }, date: { en: "In progress", ru: "В работе" } }
    ],
    recommendation: {
      en: "Pause onboarding until beneficial ownership is confirmed through certified documents.",
      ru: "Приостановить онбординг до подтверждения бенефициарного владения заверенными документами."
    }
  },
  {
    id: "baltic-freight",
    subject: { en: "Baltic Freight Partners", ru: "Baltic Freight Partners" },
    type: { en: "Vendor Review", ru: "Проверка поставщика" },
    status: "New",
    risk: "Medium",
    score: 61,
    deadline: { en: "29 May 2026", ru: "29 мая 2026" },
    analyst: { en: "Nadia Brooks", ru: "Надя Брукс" },
    keyFindings: [
      {
        en: "Initial intake complete and source collection scheduled.",
        ru: "Первичная заявка принята, сбор источников запланирован."
      },
      {
        en: "No immediate sanctions match in mock screening dataset.",
        ru: "Прямых санкционных совпадений в mock-скрининге не найдено."
      },
      {
        en: "Financial exposure assessment has not started.",
        ru: "Оценка финансовой экспозиции ещё не начата."
      }
    ],
    timeline: [
      { label: { en: "Request accepted", ru: "Запрос принят" }, date: { en: "21 May", ru: "21 мая" } },
      { label: { en: "Source collection", ru: "Сбор источников" }, date: { en: "Scheduled", ru: "Запланировано" } }
    ],
    recommendation: {
      en: "Maintain standard vendor onboarding hold until the commercial reliability review is complete.",
      ru: "Сохранять стандартную паузу в онбординге до завершения проверки коммерческой надёжности."
    }
  },
  {
    id: "ardent-holdings",
    subject: { en: "Ardent Holdings FZCO", ru: "Ardent Holdings FZCO" },
    type: { en: "Sanctions Screening", ru: "Санкционный скрининг" },
    status: "Analyst review",
    risk: "Medium",
    score: 67,
    deadline: { en: "23 May 2026", ru: "23 мая 2026" },
    analyst: { en: "Omar Valen", ru: "Омар Вален" },
    keyFindings: [
      {
        en: "No direct sanctions listing identified.",
        ru: "Прямое включение в санкционные списки не выявлено."
      },
      {
        en: "One minority shareholder has historic exposure to restricted sectors.",
        ru: "Один миноритарный акционер ранее был связан с ограниченными секторами."
      },
      {
        en: "Trade route review indicates elevated documentation requirements.",
        ru: "Анализ торгового маршрута указывает на повышенные требования к документам."
      }
    ],
    timeline: [
      { label: { en: "Request accepted", ru: "Запрос принят" }, date: { en: "19 May", ru: "19 мая" } },
      { label: { en: "Screening complete", ru: "Скрининг завершён" }, date: { en: "20 May", ru: "20 мая" } },
      { label: { en: "Analyst review", ru: "Аналитическая проверка" }, date: { en: "21 May", ru: "21 мая" } }
    ],
    recommendation: {
      en: "Continue with compliance memo and require updated end-user documentation before transaction approval.",
      ru: "Продолжить с compliance-мемо и запросить обновлённые документы конечного пользователя до одобрения сделки."
    }
  }
];

export const reports: Report[] = [
  {
    id: "candidate-screening-report",
    title: { en: "Candidate Screening Report", ru: "Отчёт по проверке кандидата" },
    date: { en: "18 May 2026", ru: "18 мая 2026" },
    type: { en: "Personnel Risk", ru: "Кадровый риск" },
    risk: "Medium"
  },
  {
    id: "counterparty-intelligence-report",
    title: { en: "Counterparty Intelligence Report", ru: "Разведывательный отчёт по контрагенту" },
    date: { en: "14 May 2026", ru: "14 мая 2026" },
    type: { en: "Counterparty", ru: "Контрагент" },
    risk: "High"
  },
  {
    id: "beneficial-ownership-review",
    title: { en: "Beneficial Ownership Review", ru: "Проверка бенефициарного владения" },
    date: { en: "09 May 2026", ru: "09 мая 2026" },
    type: { en: "Ownership", ru: "Владение" },
    risk: "Medium"
  },
  {
    id: "vendor-integrity-report",
    title: { en: "Vendor Integrity Report", ru: "Отчёт о благонадёжности поставщика" },
    date: { en: "03 May 2026", ru: "03 мая 2026" },
    type: { en: "Vendor", ru: "Поставщик" },
    risk: "Low"
  }
];

export const signals: Signal[] = [
  {
    id: "litigation-signal",
    title: { en: "Litigation signal", ru: "Судебный сигнал" },
    severity: "High",
    affected: { en: "Northbridge Supply LLC", ru: "Northbridge Supply LLC" },
    explanation: {
      en: "A fresh commercial claim was indexed against an affiliated distributor.",
      ru: "В отношении аффилированного дистрибьютора обнаружен новый коммерческий иск."
    },
    recommendedAction: {
      en: "Request updated litigation disclosure before contract execution.",
      ru: "Запросить обновлённое раскрытие судебных споров до подписания договора."
    }
  },
  {
    id: "sanctions-exposure",
    title: { en: "Sanctions exposure", ru: "Санкционная экспозиция" },
    severity: "Medium",
    affected: { en: "Ardent Holdings FZCO", ru: "Ardent Holdings FZCO" },
    explanation: {
      en: "A minority shareholder is linked to a sector that requires enhanced controls.",
      ru: "Миноритарный акционер связан с сектором, требующим усиленных контролей."
    },
    recommendedAction: {
      en: "Run final sanctions memo and document end-user declarations.",
      ru: "Подготовить финальное санкционное мемо и зафиксировать декларации конечного пользователя."
    }
  },
  {
    id: "reputation-issue",
    title: { en: "Reputation issue", ru: "Репутационный вопрос" },
    severity: "Medium",
    affected: { en: "Ilya Sorokin", ru: "Илья Сорокин" },
    explanation: {
      en: "One adverse media reference was found in a regional business publication.",
      ru: "В региональном деловом издании обнаружено одно негативное упоминание."
    },
    recommendedAction: {
      en: "Clarify context during final interview and record candidate response.",
      ru: "Уточнить контекст на финальном интервью и зафиксировать ответ кандидата."
    }
  },
  {
    id: "ownership-change",
    title: { en: "Ownership change", ru: "Изменение владения" },
    severity: "Critical",
    affected: { en: "Orion Trade Beneficial Network", ru: "Бенефициарная сеть Orion Trade" },
    explanation: {
      en: "A new holding layer appeared during the ongoing beneficial owner review.",
      ru: "В ходе проверки бенефициаров появился новый уровень холдинговой структуры."
    },
    recommendedAction: {
      en: "Suspend onboarding until updated corporate documents are received.",
      ru: "Приостановить онбординг до получения обновлённых корпоративных документов."
    }
  },
  {
    id: "adverse-media",
    title: { en: "Adverse media", ru: "Негативные медиа" },
    severity: "Low",
    affected: { en: "Baltic Freight Partners", ru: "Baltic Freight Partners" },
    explanation: {
      en: "Historic press mention references a delayed customs clearance incident.",
      ru: "Архивное упоминание в прессе связано с задержкой таможенного оформления."
    },
    recommendedAction: {
      en: "Keep under observation and request logistics compliance policy.",
      ru: "Оставить под наблюдением и запросить политику логистического комплаенса."
    }
  }
];

export const checkTypes: LocalizedText[] = [
  { en: "Counterparty Review", ru: "Проверка контрагента" },
  { en: "Candidate Screening", ru: "Проверка кандидата" },
  { en: "Beneficial Owner Review", ru: "Проверка бенефициара" },
  { en: "Sanctions Screening", ru: "Санкционный скрининг" },
  { en: "Vendor Review", ru: "Проверка поставщика" }
];

export const siteContent: SiteContentItem[] = [
  {
    id: "strategic-due-diligence",
    category: "Publication",
    title: {
      en: "Strategic Due Diligence: Beyond Registry Checks",
      ru: "Стратегический Due Diligence: за пределами реестровых проверок"
    },
    excerpt: {
      en: "How corporate intelligence helps boards identify hidden ownership, litigation, sanctions, and reputation exposure before a deal becomes irreversible.",
      ru: "Как корпоративная разведка помогает советам директоров выявлять скрытое владение, судебные риски, санкционную и репутационную экспозицию до необратимого этапа сделки."
    },
    date: { en: "21 May 2026", ru: "21 мая 2026" },
    readTime: { en: "7 min read", ru: "7 минут" },
    url: "https://heimdall-group.ru/publications/strategic-due-diligence",
    tags: [
      { en: "Due diligence", ru: "Due diligence" },
      { en: "Board risk", ru: "Риски для совета" }
    ]
  },
  {
    id: "sanctions-update-may",
    category: "News",
    title: {
      en: "May Sanctions Monitoring Update",
      ru: "Майское обновление санкционного мониторинга"
    },
    excerpt: {
      en: "HEIMDALL analysts summarize the latest sanctions exposure patterns affecting logistics, dual-use goods, and beneficial ownership structures.",
      ru: "Аналитики HEIMDALL разбирают новые паттерны санкционной экспозиции в логистике, товарах двойного назначения и структурах бенефициарного владения."
    },
    date: { en: "18 May 2026", ru: "18 мая 2026" },
    readTime: { en: "4 min read", ru: "4 минуты" },
    url: "https://heimdall-group.ru/news/may-sanctions-monitoring-update",
    tags: [
      { en: "Sanctions", ru: "Санкции" },
      { en: "Monitoring", ru: "Мониторинг" }
    ]
  },
  {
    id: "candidate-screening-risk",
    category: "Insight",
    title: {
      en: "Executive Candidate Screening For Sensitive Roles",
      ru: "Проверка кандидатов на чувствительные руководящие роли"
    },
    excerpt: {
      en: "A practical framework for checking senior candidates without turning hiring into a slow compliance ritual.",
      ru: "Практический подход к проверке руководителей, который не превращает найм в долгий compliance-ритуал."
    },
    date: { en: "12 May 2026", ru: "12 мая 2026" },
    readTime: { en: "5 min read", ru: "5 минут" },
    url: "https://heimdall-group.ru/insights/executive-candidate-screening",
    tags: [
      { en: "Screening", ru: "Скрининг" },
      { en: "Hiring risk", ru: "Кадровый риск" }
    ]
  },
  {
    id: "enhanced-support-launch",
    category: "Press",
    title: {
      en: "HEIMDALL Expands Enhanced Business Support",
      ru: "HEIMDALL расширяет направление комплексного сопровождения бизнеса"
    },
    excerpt: {
      en: "The service combines ongoing risk monitoring, analyst-led reviews, and confidential intelligence reporting for corporate clients.",
      ru: "Сервис объединяет постоянный риск-мониторинг, аналитические проверки и конфиденциальную разведывательную отчётность для корпоративных клиентов."
    },
    date: { en: "04 May 2026", ru: "04 мая 2026" },
    readTime: { en: "3 min read", ru: "3 минуты" },
    url: "https://heimdall-group.ru/press/enhanced-business-support",
    tags: [
      { en: "HEIMDALL", ru: "HEIMDALL" },
      { en: "Support", ru: "Сопровождение" }
    ]
  }
];
