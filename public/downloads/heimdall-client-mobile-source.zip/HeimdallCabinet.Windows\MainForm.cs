using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeimdallCabinet.Windows;

public sealed class MainForm : Form
{
    private readonly IHeimdallApi _api;
    private CabinetSnapshot _snapshot;
    private readonly Panel _content = new();

    public MainForm(IHeimdallApi api, CabinetSnapshot snapshot)
    {
        _api = api;
        _snapshot = snapshot;

        Text = "Heimdall - личный кабинет";
        MinimumSize = new Size(1060, 720);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.Background;

        var shell = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            BackColor = Theme.Background
        };
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        shell.Controls.Add(BuildSidebar(), 0, 0);
        _content.Dock = DockStyle.Fill;
        _content.AutoScroll = true;
        _content.Padding = new Padding(24);
        _content.BackColor = Theme.Background;
        shell.Controls.Add(_content, 1, 0);
        Controls.Add(shell);

        ShowDashboard();
    }

    private Control BuildSidebar()
    {
        var sidebar = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Padding = new Padding(16),
            BackColor = Color.FromArgb(13, 35, 37)
        };

        sidebar.Controls.Add(Theme.Label("HEIMDALL", new Font("Segoe UI", 22, FontStyle.Bold), Color.White));
        sidebar.Controls.Add(Theme.Label("Личный кабинет", Theme.SmallFont, Color.FromArgb(195, 212, 210)));
        sidebar.Controls.Add(NavButton("Главная", ShowDashboard));
        sidebar.Controls.Add(NavButton("Заявки", ShowRequests));
        sidebar.Controls.Add(NavButton("Документы", ShowDocuments));
        sidebar.Controls.Add(NavButton("Финансы", ShowFinance));
        sidebar.Controls.Add(NavButton("Профиль", ShowProfile));

        var logout = NavButton("Выйти", Close);
        logout.BackColor = Color.FromArgb(95, 31, 31);
        sidebar.Controls.Add(logout);
        return sidebar;
    }

    private Button NavButton(string text, Action action)
    {
        var button = Theme.Button(text, Color.FromArgb(25, 74, 73));
        button.Width = 190;
        button.TextAlign = ContentAlignment.MiddleLeft;
        button.Click += (_, _) => action();
        return button;
    }

    private void SetContent(string title)
    {
        _content.Controls.Clear();
        _content.Controls.Add(Theme.Label(title, Theme.TitleFont));
    }

    private void ShowDashboard()
    {
        SetContent("Кабинет");
        _content.Controls.Add(Theme.Label($"Здравствуйте, {_snapshot.Profile.FullName}", Theme.HeadingFont));
        _content.Controls.Add(Theme.Label(_snapshot.Profile.Company, Theme.BodyFont, Theme.Muted));

        var grid = new TableLayoutPanel
        {
            ColumnCount = 4,
            RowCount = 1,
            Width = 760,
            Height = 120,
            Margin = new Padding(0, 12, 0, 12)
        };
        for (var i = 0; i < 4; i++)
        {
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        }

        grid.Controls.Add(SummaryCard("Заявки", _snapshot.Summary.ActiveRequests.ToString()), 0, 0);
        grid.Controls.Add(SummaryCard("На подпись", _snapshot.Summary.DocumentsToSign.ToString()), 1, 0);
        grid.Controls.Add(SummaryCard("К оплате", _snapshot.Summary.UnpaidInvoices.ToString()), 2, 0);
        grid.Controls.Add(SummaryCard("Баллы", _snapshot.Summary.LoyaltyPoints.ToString()), 3, 0);
        _content.Controls.Add(grid);

        _content.Controls.Add(ManagerCard());
        _content.Controls.Add(Theme.Label("Последние заявки", Theme.HeadingFont));
        foreach (var request in _snapshot.Requests.Take(3))
        {
            _content.Controls.Add(RequestCard(request));
        }

        _content.Controls.Add(Theme.Label("Уведомления", Theme.HeadingFont));
        foreach (var notification in _snapshot.Notifications.Take(2))
        {
            _content.Controls.Add(NotificationCard(notification));
        }
    }

    private Panel SummaryCard(string title, string value)
    {
        var card = Theme.Card();
        card.Width = 175;
        card.Height = 100;
        card.Controls.Add(Stack(
            Theme.Label(value, new Font("Segoe UI", 24, FontStyle.Bold), Theme.Ink),
            Theme.Label(title, Theme.SmallFont, Theme.Muted)));
        return card;
    }

    private Panel ManagerCard()
    {
        var card = Theme.Card();
        card.Width = 760;
        card.Height = 105;
        card.Controls.Add(Stack(
            Theme.Label("Ваш менеджер", Theme.SmallFont, Theme.Muted),
            Theme.Label(_snapshot.Profile.ManagerName, Theme.HeadingFont),
            Theme.Label("Ответит по заявкам, документам и оплатам", Theme.BodyFont, Theme.Muted)));
        return card;
    }

    private void ShowRequests()
    {
        SetContent("Заявки");
        var create = Theme.Button("Создать заявку");
        create.Width = 180;
        create.Click += async (_, _) => await CreateRequestAsync();
        _content.Controls.Add(create);

        foreach (var request in _snapshot.Requests)
        {
            _content.Controls.Add(RequestCard(request));
        }
    }

    private async Task CreateRequestAsync()
    {
        using var dialog = new NewRequestForm();
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        await _api.CreateRequestAsync(dialog.RequestTitle, dialog.Service, dialog.Comment);
        _snapshot = await _api.RefreshCabinetAsync();
        ShowRequests();
    }

    private Panel RequestCard(CabinetRequest request)
    {
        var card = Theme.Card();
        card.Width = 760;
        card.Height = 125;
        card.Controls.Add(Stack(
            Theme.Label($"{request.Title}  ·  {request.Status.ToRu()}", Theme.HeadingFont),
            Theme.Label(request.Service, Theme.BodyFont, Theme.Muted),
            Theme.Label(request.Comment, Theme.BodyFont, Theme.Muted),
            Theme.Label($"Обновлено {request.UpdatedAt:dd.MM.yyyy}", Theme.SmallFont, Theme.Muted)));
        return card;
    }

    private void ShowDocuments()
    {
        SetContent("Документы");
        foreach (var document in _snapshot.Documents)
        {
            var suffix = document.RequiresSignature ? " · Подписать" : "";
            var card = Theme.Card();
            card.Width = 760;
            card.Height = 92;
            card.Controls.Add(Stack(
                Theme.Label(document.Title + suffix, Theme.HeadingFont),
                Theme.Label($"{document.Kind.ToRu()} · {document.Date:dd.MM.yyyy}", Theme.BodyFont, Theme.Muted)));
            _content.Controls.Add(card);
        }
    }

    private void ShowFinance()
    {
        SetContent("Финансы");
        var pendingTotal = _snapshot.Invoices
            .Where(invoice => invoice.Status != InvoiceStatus.Paid)
            .Sum(invoice => invoice.Amount);

        var totalCard = Theme.Card();
        totalCard.Width = 760;
        totalCard.Height = 125;
        totalCard.Controls.Add(Stack(
            Theme.Label("К оплате", Theme.BodyFont, Theme.Muted),
            Theme.Label(pendingTotal.ToString("C0", CultureInfo.GetCultureInfo("ru-RU")), new Font("Segoe UI", 24, FontStyle.Bold)),
            Theme.Label("Оплата подключается через платежный шлюз сайта", Theme.SmallFont, Theme.Muted)));
        _content.Controls.Add(totalCard);

        foreach (var invoice in _snapshot.Invoices)
        {
            var card = Theme.Card();
            card.Width = 760;
            card.Height = 105;
            card.Controls.Add(Stack(
                Theme.Label($"{invoice.Number} · {invoice.Status.ToRu()}", Theme.HeadingFont),
                Theme.Label($"До {invoice.DueDate:dd.MM.yyyy}", Theme.BodyFont, Theme.Muted),
                Theme.Label(invoice.Amount.ToString("C0", CultureInfo.GetCultureInfo("ru-RU")), Theme.HeadingFont)));
            _content.Controls.Add(card);
        }
    }

    private async void ShowProfile()
    {
        SetContent("Профиль");
        _content.Controls.Add(Theme.Label(_snapshot.Profile.FullName, Theme.HeadingFont));
        _content.Controls.Add(Theme.Label(_snapshot.Profile.Company, Theme.BodyFont, Theme.Muted));
        _content.Controls.Add(Theme.Label($"E-mail: {_snapshot.Profile.Email}", Theme.BodyFont));
        _content.Controls.Add(Theme.Label($"Телефон: {_snapshot.Profile.Phone}", Theme.BodyFont));
        _content.Controls.Add(Theme.Label($"Менеджер: {_snapshot.Profile.ManagerName}", Theme.BodyFont));

        var markRead = Theme.Button("Отметить уведомления прочитанными");
        markRead.Width = 300;
        markRead.Click += async (_, _) =>
        {
            await _api.MarkNotificationsReadAsync();
            _snapshot = await _api.RefreshCabinetAsync();
            ShowProfile();
        };
        _content.Controls.Add(markRead);

        _content.Controls.Add(Theme.Label("Уведомления", Theme.HeadingFont));
        foreach (var notification in _snapshot.Notifications)
        {
            _content.Controls.Add(NotificationCard(notification));
        }

        await Task.CompletedTask;
    }

    private Panel NotificationCard(CabinetNotification notification)
    {
        var card = Theme.Card();
        card.Width = 760;
        card.Height = 98;
        var marker = notification.IsUnread ? "● " : "";
        card.Controls.Add(Stack(
            Theme.Label(marker + notification.Title, Theme.HeadingFont),
            Theme.Label(notification.Message, Theme.BodyFont, Theme.Muted),
            Theme.Label(notification.Date.ToString("dd.MM.yyyy"), Theme.SmallFont, Theme.Muted)));
        return card;
    }

    private static FlowLayoutPanel Stack(params Control[] controls)
    {
        var stack = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = false,
            BackColor = Theme.Surface
        };
        stack.Controls.AddRange(controls);
        return stack;
    }
}
